<?php
require_once 'config.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = (string)($_POST['new_password'] ?? '');
    $confirm  = (string)($_POST['confirm_password'] ?? '');

    if (strlen($password) < 8) {
        $message = 'Password must contain at least 8 characters.';
    } elseif ($password !== $confirm) {
        $message = 'Passwords do not match.';
    } else {
        $owner = q(
            "SELECT id FROM users
             WHERE username = ? AND role = 'owner' AND active = 1",
            ['owner']
        )->fetch();

        if (!$owner) {
            $message = 'Active Owner account was not found.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);

            q(
                "UPDATE users SET password_hash = ? WHERE id = ?",
                [$hash, $owner['id']]
            );

            $message = 'Owner password successfully reset!';
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>AgriSTIM Owner Password Reset</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: Arial;
            background: #edf3ed;
            padding: 40px 15px;
        }
        .container {
            max-width: 400px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 12px;
        }
        input {
            width: 100%;
            box-sizing: border-box;
            padding: 12px;
            margin: 10px 0 18px;
        }
        button {
            width: 100%;
            padding: 13px;
            background: #287b46;
            color: white;
            border: 0;
            cursor: pointer;
        }
        .message {
            padding: 12px;
            background: #e6f4e9;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>AgriSTIM Owner Password Reset</h2>

    <?php if ($message !== ''): ?>
        <div class="message">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <?= csrf_field() ?>

        <label>New Owner Password</label>
        <input type="password" name="new_password"
               minlength="8" required>

        <label>Confirm New Password</label>
        <input type="password" name="confirm_password"
               minlength="8" required>

        <button type="submit">Reset Owner Password</button>
    </form>
</div>
</body>
</html>
