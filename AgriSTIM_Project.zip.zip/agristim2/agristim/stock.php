<?php require 'config.php'; need();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $pid = (int)post('product_id'); $qty = post('qty'); $bn = post('batch_no'); $sup = post('supplier'); $uid = (int)post('unit_id'); $exp = post('expiry');
  $p = q('SELECT * FROM products WHERE id=? AND archived=0', [$pid])->fetch();
  $err = '';
  if (!$p) $err = 'Please choose a product.';
  elseif (!ctype_digit((string)$qty) || (int)$qty < 1 || (int)$qty > 1000000) $err = 'Quantity must be a whole number of 1 or more.';
  elseif (mb_strlen($bn) > 40 || mb_strlen($sup) > 100) $err = 'Batch number or supplier is too long.';
  elseif ($exp !== '' && !(($d = DateTime::createFromFormat('Y-m-d', $exp)) && $d->format('Y-m-d') === $exp)) $err = 'Please enter a valid expiry date.';
  elseif ($uid && !q('SELECT 1 FROM storage_units WHERE id=?', [$uid])->fetch()) $err = 'Unknown storage unit.';
  if ($err) flash('danger', $err);
  else {
    if ($bn === '') $bn = (string)(1 + (int)q('SELECT COUNT(*) c FROM batches WHERE product_id=?', [$pid])->fetch()['c']);
    q('INSERT INTO batches(product_id,batch_no,supplier,unit_id,qty_received,qty_remaining,expiry) VALUES(?,?,?,?,?,?,?)',
      [$pid, $bn, $sup ?: null, $uid ?: null, (int)$qty, (int)$qty, $exp ?: null]);
    audit("stock-in product $pid batch $bn qty " . (int)$qty);
    run_checks();
    flash('success', 'Added <b>' . (int)$qty . '</b> ' . h($p['unit']) . ' of <b>' . h($p['name']) . '</b> (batch ' . h($bn) . ').');
    if ($exp !== '' && $exp < date('Y-m-d')) flash('warning', 'That batch is already expired, so it cannot be sold. Record it under Stock-Out / Losses.');
  }
  go('stock.php');
}
$prods = q('SELECT p.id,p.name,p.unit,p.category,COALESCE((SELECT SUM(qty_remaining) FROM batches WHERE product_id=p.id),0) stock FROM products p WHERE p.archived=0 ORDER BY p.name')->fetchAll();
$units = q('SELECT id,name FROM storage_units ORDER BY name')->fetchAll();
$rows = q('SELECT b.*,p.name,p.unit,u.name uname FROM batches b JOIN products p ON p.id=b.product_id LEFT JOIN storage_units u ON u.id=b.unit_id ORDER BY b.received_at DESC,b.id DESC LIMIT 40')->fetchAll();
top('Stock-In', 'Record new deliveries. Each delivery becomes a batch with its own expiry date.'); ?>
<div class="row g-4">
  <div class="col-lg-4"><div class="ag-card ag-card-form">
    <div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-box-arrow-in-down"></i> New delivery</h2></div>
    <form method="post"><?= csrf_field() ?>
      <label class="form-label">Product</label>
      <select class="form-select mb-2" name="product_id" required><option value="">Choose&hellip;</option>
        <?php foreach ($prods as $p): ?><option value="<?= (int)$p['id'] ?>"><?= h($p['name']) ?> (<?= (int)$p['stock'] ?> in stock)</option><?php endforeach; ?></select>
      <div class="row g-2 mb-2"><div class="col-6"><label class="form-label">Quantity</label><input class="form-control" type="number" name="qty" min="1" step="1" required></div>
        <div class="col-6"><label class="form-label">Batch no.</label><input class="form-control" name="batch_no" maxlength="40" placeholder="auto"></div></div>
      <label class="form-label">Supplier</label><input class="form-control mb-2" name="supplier" maxlength="100">
      <label class="form-label">Expiry date</label><input class="form-control mb-1" type="date" name="expiry"><div class="form-text mb-2">Leave empty for items that do not expire (equipment).</div>
      <label class="form-label">Stored in</label>
      <select class="form-select mb-3" name="unit_id"><option value="0">Shelf / no cold storage</option>
        <?php foreach ($units as $u): ?><option value="<?= (int)$u['id'] ?>"><?= h($u['name']) ?></option><?php endforeach; ?></select>
      <button class="btn btn-success w-100"><i class="bi bi-check2 me-1"></i>Add to stock</button>
    </form>
  </div></div>
  <div class="col-lg-8"><div class="ag-card">
    <div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-clock-history"></i> Recent batches</h2></div>
    <?php if (!$rows): echo empty_state('bi-box-seam', 'No batches yet', 'Add your first delivery on the left.'); else: ?>
    <div class="table-responsive"><table class="table"><thead><tr><th>Received</th><th>Product</th><th>Batch</th><th>Supplier</th><th class="ag-num">Received</th><th class="ag-num">Left</th><th>Expiry</th><th>Stored in</th></tr></thead><tbody>
    <?php foreach ($rows as $b): $ex = $b['expiry'] && $b['expiry'] < date('Y-m-d') && $b['qty_remaining'] > 0; ?>
      <tr class="<?= $ex ? 'ag-row-danger' : '' ?>"><td class="text-nowrap small"><?= nice_date($b['received_at']) ?></td><td class="ag-strong"><?= h($b['name']) ?></td><td><?= h($b['batch_no']) ?></td><td><?= h($b['supplier'] ?: '—') ?></td>
        <td class="ag-num"><?= (int)$b['qty_received'] ?></td><td class="ag-num"><?= (int)$b['qty_remaining'] ?></td>
        <td class="text-nowrap"><?= nice_date($b['expiry'], false) ?><?php if ($ex): ?> <span class="ag-badge ag-badge-danger">Expired</span><?php endif; ?></td><td><?= h($b['uname'] ?: '—') ?></td></tr>
    <?php endforeach; ?></tbody></table></div><?php endif; ?>
  </div></div>
</div>
<?php bottom();
