<?php require 'config.php'; need(true);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $do = post('do'); $id = (int)post('id'); $self = (int)me()['id'];
  $owners = function () { return (int)q("SELECT COUNT(*) c FROM users WHERE role='owner' AND active=1")->fetch()['c']; };

  if ($do === 'add') {
    $un = strtolower(post('username')); $fn = post('full_name'); $role = post('role') === 'owner' ? 'owner' : 'staff'; $pw = (string)post('password');
    if (!preg_match('/^[a-z0-9_.-]{3,30}$/', $un)) flash('danger', 'Username: 3-30 letters, numbers, dot, dash or underscore.');
    elseif ($fn === '' || mb_strlen($fn) > 100) flash('danger', 'Please enter the full name.');
    elseif (strlen($pw) < 8) flash('danger', 'Password must be at least 8 characters.');
    elseif (q('SELECT 1 FROM users WHERE username=?', [$un])->fetch()) flash('danger', 'That username is taken.');
    else { q('INSERT INTO users(username,full_name,password_hash,role,active) VALUES(?,?,?,?,1)', [$un, $fn, password_hash($pw, PASSWORD_DEFAULT), $role]); audit("user added $un ($role)"); flash('success', "User <b>" . h($un) . '</b> created.'); }
  }
  $u = $id ? q('SELECT * FROM users WHERE id=?', [$id])->fetch() : null;
  if ($u && $do === 'update') {
    $fn = post('full_name'); $role = post('role') === 'owner' ? 'owner' : 'staff';
    if ($fn === '' || mb_strlen($fn) > 100) flash('danger', 'Please enter the full name.');
    elseif ($id === $self && $role !== 'owner') flash('danger', 'You cannot remove your own owner role.');
    else { q('UPDATE users SET full_name=?,role=? WHERE id=?', [$fn, $role, $id]); audit("user updated {$u['username']} ($role)"); flash('success', 'User saved.'); }
  }
  if ($u && $do === 'password') {
    $pw = (string)post('password');
    if (strlen($pw) < 8) flash('danger', 'Password must be at least 8 characters.');
    else { q('UPDATE users SET password_hash=? WHERE id=?', [password_hash($pw, PASSWORD_DEFAULT), $id]); audit("user password reset {$u['username']}"); flash('success', 'Password changed for <b>' . h($u['username']) . '</b>.'); }
  }
  if ($u && $do === 'toggle') {
    if ($id === $self) flash('danger', 'You cannot deactivate your own account.');
    elseif ($u['active'] && $u['role'] === 'owner' && $owners() <= 1) flash('danger', 'There must be at least one active owner.');
    else { q('UPDATE users SET active=? WHERE id=?', [$u['active'] ? 0 : 1, $id]); audit('user ' . ($u['active'] ? 'deactivated ' : 'activated ') . $u['username']); flash('success', 'User ' . ($u['active'] ? 'deactivated.' : 'activated.')); }
  }
  go('users.php');
}
$rows = q('SELECT u.*,(SELECT MAX(created_at) FROM audit_log WHERE user_id=u.id AND action=\'login\') last_login FROM users u ORDER BY u.active DESC,u.role,u.username')->fetchAll();
top('Users', 'Create accounts for staff, reset passwords and switch accounts off.'); ?>
<div class="row g-4">
  <div class="col-lg-4"><div class="ag-card ag-card-form"><div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-person-plus"></i> New user</h2></div>
    <form method="post" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="do" value="add">
      <label class="form-label">Username</label><input class="form-control mb-2" name="username" maxlength="30" required>
      <label class="form-label">Full name</label><input class="form-control mb-2" name="full_name" maxlength="100" required>
      <label class="form-label">Role</label><select class="form-select mb-2" name="role"><option value="staff">Staff</option><option value="owner">Owner</option></select>
      <label class="form-label">Password</label><input class="form-control mb-1" type="password" name="password" minlength="8" autocomplete="new-password" required><div class="form-text mb-3">At least 8 characters.</div>
      <button class="btn btn-success w-100">Create user</button></form></div></div>
  <div class="col-lg-8"><div class="ag-card"><div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-people"></i> All users <span class="ag-badge ag-badge-muted"><?= count($rows) ?></span></h2></div>
    <?php foreach ($rows as $u): $me = (int)$u['id'] === (int)me()['id']; ?>
      <div class="border rounded-3 p-3 mb-2 <?= $u['active'] ? '' : 'ag-row-muted' ?>">
        <div class="d-flex flex-wrap justify-content-between gap-2 mb-2"><div><span class="ag-strong"><?= h($u['username']) ?></span> <?= $me ? '<span class="ag-badge ag-badge-ok">You</span>' : '' ?> <?= $u['active'] ? '' : '<span class="ag-badge ag-badge-dark">Inactive</span>' ?>
          <span class="ag-sub">Last login: <?= nice_date($u['last_login']) ?></span></div></div>
        <form method="post" class="row g-2 mb-2"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
          <div class="col-sm-5"><input class="form-control form-control-sm" name="full_name" value="<?= h($u['full_name']) ?>" maxlength="100" required></div>
          <div class="col-sm-3"><select class="form-select form-select-sm" name="role"><option value="staff" <?= $u['role'] === 'staff' ? 'selected' : '' ?>>Staff</option><option value="owner" <?= $u['role'] === 'owner' ? 'selected' : '' ?>>Owner</option></select></div>
          <div class="col-auto"><button class="btn btn-sm btn-light" name="do" value="update">Save</button>
            <?php if (!$me): ?><button class="btn btn-sm <?= $u['active'] ? 'btn-outline-danger' : 'btn-outline-success' ?>" name="do" value="toggle" formnovalidate><?= $u['active'] ? 'Deactivate' : 'Activate' ?></button><?php endif; ?></div></form>
        <form method="post" class="d-flex gap-2" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><input type="hidden" name="do" value="password">
          <input class="form-control form-control-sm" style="max-width:260px" type="password" name="password" minlength="8" placeholder="New password (8+ characters)" autocomplete="new-password" required><button class="btn btn-sm btn-light">Change password</button></form>
      </div>
    <?php endforeach; ?></div></div>
</div>
<?php bottom();
