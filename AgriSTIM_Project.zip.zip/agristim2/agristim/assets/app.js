/* AgriSTIM page scripts (loaded in <head>, so everything waits for DOMContentLoaded) */
document.addEventListener('submit', function (e) {
  var m = e.target.getAttribute && e.target.getAttribute('data-confirm');
  if (m && !confirm(m)) e.preventDefault();
});

function agEsc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

/* Live storage-unit cards. Reads api/latest.php every 30 seconds.
   agLive('unitCards', {chart:true}) */
var agCharts = {};
function agLive(boxId, opt) {
  opt = opt || {};
  var box = document.getElementById(boxId);
  if (!box) return;
  function draw(list) {
    if (!list.length) {
      box.innerHTML = '<div class="col-12"><div class="ag-card"><div class="ag-empty"><div class="ag-empty-icon"><i class="bi bi-thermometer-half"></i></div><h6>No storage units yet</h6><p>Add a storage unit on the Temperature page.</p></div></div></div>';
      return;
    }
    box.innerHTML = list.map(function (u, i) {
      var cls = u.status === 'Offline' ? 'offline' : (u.out ? 'out' : '');
      var badge = u.status === 'Normal' ? 'ag-badge-ok' : (u.status === 'Offline' ? 'ag-badge-dark' : 'ag-badge-danger');
      return '<div class="col-md-6' + (opt.chart ? '' : ' col-xl-6') + '"><div class="ag-unit ' + cls + '">' +
        '<div class="ag-unit-name"><i class="bi bi-snow2 me-1"></i>' + agEsc(u.name) + '</div>' +
        '<div class="ag-unit-temp">' + (u.temp === null ? '--' : agEsc(u.temp)) + '<small> &deg;C</small></div>' +
        '<div class="ag-unit-range">Safe range ' + agEsc(u.min) + ' to ' + agEsc(u.max) + ' &deg;C' +
        (u.humidity !== null ? ' &middot; Humidity ' + agEsc(u.humidity) + '%' : '') + '</div>' +
        (opt.chart ? '<div style="height:120px;margin-top:.6rem"><canvas id="agc' + i + '"></canvas></div>' : '') +
        '<div class="ag-unit-meta"><span class="ag-badge ' + badge + '">' + agEsc(u.status) + '</span>' +
        '<span class="ag-unit-time">' + (u.last ? 'Last reading ' + agEsc(u.last) : 'No readings yet') + '</span></div>' +
        '</div></div>';
    }).join('');
    if (opt.chart && window.Chart) {
      list.forEach(function (u, i) {
        var c = document.getElementById('agc' + i);
        if (!c || !u.series.length) return;
        new Chart(c, {
          type: 'line',
          data: {
            labels: u.series.map(function (p) { return p.t.slice(11, 16); }),
            datasets: [{ data: u.series.map(function (p) { return p.v; }), borderColor: u.out ? '#c4473d' : '#2f7a45', backgroundColor: 'rgba(47,122,69,.08)', fill: true, tension: .3, pointRadius: 0, borderWidth: 2 }]
          },
          options: { animation: false, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { ticks: { maxTicksLimit: 6 } } } }
        });
      });
    }
  }
  function load() {
    fetch('api/latest.php', { credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.json() : Promise.reject(); })
      .then(draw)
      .catch(function () { box.innerHTML = '<div class="col-12 text-muted small">Could not load sensor data. Are you still logged in?</div>'; });
  }
  load();
  setInterval(load, 30000);
}
