<?php require 'config.php'; need(true);
$types = ['sales' => 'Sales & profit by day', 'best' => 'Best-selling products', 'losses' => 'Losses', 'stock' => 'Inventory value', 'expiry' => 'Batches & expiry'];
$t = isset($types[$_GET['t'] ?? '']) ? $_GET['t'] : 'sales';
$ok = function ($d) { $x = DateTime::createFromFormat('Y-m-d', (string)$d); return $x && $x->format('Y-m-d') === $d; };
$from = $ok($_GET['from'] ?? '') ? $_GET['from'] : date('Y-m-01'); $to = $ok($_GET['to'] ?? '') ? $_GET['to'] : date('Y-m-d');
if ($from > $to) { $swap = $from; $from = $to; $to = $swap; }
$r = [$from, $to];

// each report: columns [label, kind] and raw rows; kind = text | int | money | date
if ($t === 'sales') {
  $cols = [['Date', 'date'], ['Sales', 'int'], ['Revenue', 'money'], ['Cost', 'money'], ['Profit', 'money']];
  $rows = q('SELECT DATE(s.created_at) d, COUNT(DISTINCT s.id) n, SUM(si.qty*si.unit_price) rev, SUM(si.qty*si.unit_cost) cost FROM sales s JOIN sale_items si ON si.sale_id=s.id
             WHERE DATE(s.created_at) BETWEEN ? AND ? GROUP BY DATE(s.created_at) ORDER BY d', $r)->fetchAll(PDO::FETCH_NUM);
  foreach ($rows as &$x) $x[] = $x[2] - $x[3]; unset($x);
} elseif ($t === 'best') {
  $cols = [['Product', 'text'], ['Qty sold', 'int'], ['Revenue', 'money'], ['Profit', 'money']];
  $rows = q('SELECT COALESCE(p.name,"Deleted product"), SUM(si.qty), SUM(si.qty*si.unit_price), SUM(si.qty*(si.unit_price-si.unit_cost)) FROM sale_items si JOIN sales s ON s.id=si.sale_id LEFT JOIN products p ON p.id=si.product_id
             WHERE DATE(s.created_at) BETWEEN ? AND ? GROUP BY si.product_id, p.name ORDER BY 2 DESC', $r)->fetchAll(PDO::FETCH_NUM);
} elseif ($t === 'losses') {
  $cols = [['Date', 'date'], ['Product', 'text'], ['Reason', 'text'], ['Qty', 'int'], ['Cost', 'money']];
  $rows = q('SELECT DATE(l.created_at), COALESCE(p.name,"Deleted product"), l.reason, l.qty, l.amount FROM losses l LEFT JOIN products p ON p.id=l.product_id
             WHERE DATE(l.created_at) BETWEEN ? AND ? ORDER BY l.id', $r)->fetchAll(PDO::FETCH_NUM);
} elseif ($t === 'stock') {
  $cols = [['Product', 'text'], ['Category', 'text'], ['In stock', 'int'], ['Value at cost', 'money'], ['Value at retail', 'money']];
  $rows = q('SELECT p.name,p.category,COALESCE(SUM(b.qty_remaining),0) s, COALESCE(SUM(b.qty_remaining),0)*p.cost_price, COALESCE(SUM(b.qty_remaining),0)*p.retail_price FROM products p LEFT JOIN batches b ON b.product_id=p.id
             WHERE p.archived=0 GROUP BY p.id,p.name,p.category,p.cost_price,p.retail_price ORDER BY p.name')->fetchAll(PDO::FETCH_NUM);
} else {
  $cols = [['Product', 'text'], ['Batch', 'text'], ['Qty left', 'int'], ['Expiry', 'date'], ['Days left', 'int']];
  $rows = q('SELECT p.name,b.batch_no,b.qty_remaining,b.expiry,DATEDIFF(b.expiry,CURDATE()) FROM batches b JOIN products p ON p.id=b.product_id WHERE b.qty_remaining>0 AND b.expiry IS NOT NULL ORDER BY b.expiry')->fetchAll(PDO::FETCH_NUM);
}
// totals for numeric columns (days-left is not summed)
$tot = []; foreach ($cols as $i => $cd) { $l = $cd[0]; $k = $cd[1]; if (($k === 'money' || $k === 'int') && $l !== 'Days left') { $tot[$i] = 0; foreach ($rows as $x) $tot[$i] += (float)$x[$i]; } }

if (isset($_GET['csv'])) {
  audit("report download $t $from to $to");
  header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="agristim-' . $t . '-' . $from . '-to-' . $to . '.csv"');
  echo "\xEF\xBB\xBF"; $o = fopen('php://output', 'w');
  fputcsv($o, array_column($cols, 0));
  foreach ($rows as $x) fputcsv($o, array_map(function ($v) { return is_string($v) && preg_match('/^[=+\-@]/', $v) ? "'" . $v : $v; }, $x));   // stop spreadsheet formula injection
  if ($tot) { $line = []; foreach ($cols as $i => $c) $line[] = $i === 0 ? 'TOTAL' : ($tot[$i] ?? ''); fputcsv($o, $line); }
  exit;
}
$usesDates = in_array($t, ['sales', 'best', 'losses']);
$fmt = function ($v, $kind) { if ($v === null) return '&mdash;'; return $kind === 'money' ? money($v) : ($kind === 'date' ? nice_date($v, false) : ($kind === 'int' ? number_format((float)$v) : h(ucfirst((string)$v)))); };
$qs = http_build_query(['t' => $t, 'from' => $from, 'to' => $to]);
top('Reports', 'Sales, profit, losses and stock. Download any report as a CSV that opens in Excel.', '<a class="btn btn-success" href="reports.php?' . h($qs) . '&csv=1"><i class="bi bi-download me-1"></i>Download CSV</a> <button class="btn btn-light" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print</button>'); ?>
<div class="ag-pills mb-3 no-print"><?php foreach ($types as $k => $l) echo "<a class='" . ($t === $k ? 'active' : '') . "' href='reports.php?t=$k&from=$from&to=$to'>" . h($l) . '</a>'; ?></div>
<?php if ($usesDates): ?><div class="ag-card mb-4 no-print"><form class="row g-2 align-items-end"><input type="hidden" name="t" value="<?= h($t) ?>">
  <div class="col-auto"><label class="form-label">From</label><input class="form-control" type="date" name="from" value="<?= h($from) ?>"></div>
  <div class="col-auto"><label class="form-label">To</label><input class="form-control" type="date" name="to" value="<?= h($to) ?>"></div>
  <div class="col-auto"><button class="btn btn-success">Show</button></div></form></div><?php endif; ?>
<div class="ag-card">
  <div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-bar-chart-line"></i> <?= h($types[$t]) ?><?php if ($usesDates): ?> <span class="ag-badge ag-badge-muted"><?= nice_date($from, false) ?> &ndash; <?= nice_date($to, false) ?></span><?php endif; ?></h2></div>
  <?php if (!$rows): echo empty_state('bi-bar-chart', 'No data', 'Nothing was recorded for this report and period.'); else: ?>
  <div class="table-responsive"><table class="table"><thead><tr><?php foreach ($cols as $cd) { $l = $cd[0]; $k = $cd[1]; echo '<th' . ($k === 'money' || $k === 'int' ? ' class="ag-num"' : '') . '>' . h($l) . '</th>'; } ?></tr></thead><tbody>
  <?php foreach ($rows as $x): ?><tr><?php foreach ($cols as $i => $cd) { $k = $cd[1]; echo '<td class="' . ($k === 'money' || $k === 'int' ? 'ag-num' : '') . ($i === 0 ? ' ag-strong' : '') . '">' . $fmt($x[$i], $k) . '</td>'; } ?></tr><?php endforeach; ?>
  <?php if ($tot): ?><tr style="background:var(--ag-mint)"><?php foreach ($cols as $i => $cd) { $k = $cd[1]; echo '<td class="' . ($k === 'money' || $k === 'int' ? 'ag-num' : '') . ' ag-strong">' . ($i === 0 ? 'TOTAL' : (isset($tot[$i]) ? $fmt($tot[$i], $k) : '')) . '</td>'; } ?></tr><?php endif; ?>
  </tbody></table></div><?php endif; ?>
</div>
<?php bottom();
