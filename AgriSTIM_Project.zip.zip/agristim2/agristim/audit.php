<?php require 'config.php'; need(true);
$k = trim($_GET['k'] ?? ''); $err = ''; $rows = [];
try {
  $rows = q('SELECT a.created_at,u.username,u.full_name,a.action FROM audit_log a LEFT JOIN users u ON u.id=a.user_id WHERE a.action LIKE ? OR u.username LIKE ? ORDER BY a.id DESC LIMIT 300', ["%$k%", "%$k%"])->fetchAll();
} catch (Throwable $e) { $err = $e->getMessage(); }
function action_icon($a) {
  foreach (['login' => 'bi-box-arrow-in-right', 'logout' => 'bi-box-arrow-right', 'price' => 'bi-tag', 'stock-in' => 'bi-box-arrow-in-down', 'stock-out' => 'bi-box-arrow-up', 'sale' => 'bi-cart3', 'user' => 'bi-person', 'alert' => 'bi-bell', 'report' => 'bi-download', 'categor' => 'bi-tags', 'storage' => 'bi-snow', 'product' => 'bi-box-seam'] as $w => $i)
    if (stripos($a, $w) !== false) return $i;
  return 'bi-dot';
}
top('Audit Log', 'Every important action, who did it and when (latest 300).'); ?>
<?php if ($err): ?><div class="alert ag-alert alert-danger"><b>Audit log error:</b> <?= h($err) ?></div><?php endif; ?>
<div class="ag-card mb-4"><form class="row g-2">
  <div class="col-md-8 col-lg-6"><div class="input-group"><span class="input-group-text"><i class="bi bi-search"></i></span><input class="form-control" name="k" value="<?= h($k) ?>" placeholder="Search actions or users (e.g. price change, stock-in, login)"></div></div>
  <div class="col-auto"><button class="btn btn-success">Search</button></div>
  <?php if ($k !== ''): ?><div class="col-auto"><a class="btn btn-light" href="audit.php">Clear</a></div><?php endif; ?>
</form></div>
<div class="ag-card">
  <?php if (!$rows): echo empty_state('bi-journal-text', 'No entries', $k !== '' ? 'Nothing matches your search.' : 'Actions will be recorded here.'); else: ?>
  <div class="table-responsive"><table class="table"><thead><tr><th>Date &amp; time</th><th>User</th><th>Action</th></tr></thead><tbody>
  <?php foreach ($rows as $r): ?><tr><td class="text-nowrap small"><?= nice_date($r['created_at']) ?></td><td><span class="ag-strong"><?= h($r['username'] ?: 'system') ?></span><span class="ag-sub"><?= h($r['full_name']) ?></span></td>
    <td><i class="bi <?= action_icon($r['action']) ?> me-2" style="color:var(--ag-green)"></i><?= h($r['action']) ?></td></tr><?php endforeach; ?>
  </tbody></table></div><?php endif; ?>
</div>
<?php bottom();
