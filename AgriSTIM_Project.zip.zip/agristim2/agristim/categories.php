<?php require 'config.php'; need(true); ensure_categories();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (post('add') !== '') {
    $n = post('name');
    if ($n === '' || mb_strlen($n) > 60) flash('danger', 'Please enter a category name (up to 60 characters).');
    elseif (q('SELECT 1 FROM categories WHERE name=?', [$n])->fetch()) flash('danger', 'That category already exists.');
    else { q('INSERT INTO categories(name) VALUES(?)', [$n]); audit("add category $n"); flash('success', 'Category <b>' . h($n) . '</b> added.'); }
  }
  if (post('rename') !== '') {
    $c = q('SELECT * FROM categories WHERE id=?', [(int)post('rename')])->fetch(); $n = post('name');
    if (!$c || $n === '') flash('danger', 'Please enter a name.');
    elseif ($n !== $c['name'] && q('SELECT 1 FROM categories WHERE name=?', [$n])->fetch()) flash('danger', 'That category already exists.');
    else {
      $pdo->beginTransaction();
      q('UPDATE categories SET name=? WHERE id=?', [$n, $c['id']]);
      q('UPDATE products SET category=? WHERE category=?', [$n, $c['name']]);
      $pdo->commit();
      audit("rename category {$c['name']} -> $n"); flash('success', 'Category renamed. Products were updated too.');
    }
  }
  if (post('delete') !== '') {
    $c = q('SELECT * FROM categories WHERE id=?', [(int)post('delete')])->fetch();
    if ($c && q('SELECT 1 FROM products WHERE category=?', [$c['name']])->fetch()) flash('danger', 'This category still has products. Move them to another category first.');
    elseif ($c) { q('DELETE FROM categories WHERE id=?', [$c['id']]); audit("delete category {$c['name']}"); flash('success', 'Category deleted.'); }
  }
  go('categories.php');
}
$rows = q('SELECT c.id,c.name,COUNT(p.id) n,SUM(p.archived=0) active FROM categories c LEFT JOIN products p ON p.category=c.name GROUP BY c.id,c.name ORDER BY c.name')->fetchAll();
top('Categories', 'Group your products. These appear in the category list on the Products page.'); ?>
<div class="row g-4">
  <div class="col-lg-4"><div class="ag-card ag-card-form">
    <div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-plus-circle"></i> New category</h2></div>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="add" value="1">
      <label class="form-label">Name</label><input class="form-control mb-3" name="name" maxlength="60" placeholder="e.g. Pet Food" required>
      <button class="btn btn-success w-100"><i class="bi bi-check2 me-1"></i>Add category</button></form>
  </div></div>
  <div class="col-lg-8"><div class="ag-card">
    <div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-tags"></i> All categories <span class="ag-badge ag-badge-muted"><?= count($rows) ?></span></h2></div>
    <?php if (!$rows): echo empty_state('bi-tags', 'No categories yet', 'Add your first category on the left.'); else: ?>
    <div class="table-responsive"><table class="table"><thead><tr><th>Category</th><th class="ag-num">Products</th><th></th></tr></thead><tbody>
    <?php foreach ($rows as $r): ?><tr>
      <td><form method="post" class="d-flex gap-2"><?= csrf_field() ?><input class="form-control form-control-sm" name="name" value="<?= h($r['name']) ?>" maxlength="60" style="max-width:260px" required>
        <button class="btn btn-sm btn-light" name="rename" value="<?= $r['id'] ?>">Rename</button></form></td>
      <td class="ag-num"><?= (int)$r['active'] ?><?php if ($r['n'] > $r['active']): ?><span class="ag-sub">+<?= $r['n'] - $r['active'] ?> archived</span><?php endif; ?></td>
      <td class="text-end"><?php if (!$r['n']): ?><form method="post" data-confirm="Delete category <?= h($r['name']) ?>?"><?= csrf_field() ?><button class="btn btn-sm btn-outline-danger" name="delete" value="<?= $r['id'] ?>"><i class="bi bi-trash"></i></button></form>
        <?php else: ?><span class="text-muted small" title="Move or archive its products first">In use</span><?php endif; ?></td>
    </tr><?php endforeach; ?>
    </tbody></table></div><?php endif; ?>
  </div></div>
</div>
<?php bottom();
