<?php require 'config.php'; need();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $bid = (int)post('batch_id'); $qty = post('qty'); $why = post('reason');
  if (!in_array($why, ['expired', 'damaged', 'spoiled'], true)) flash('danger', 'Please choose a reason.');
  elseif (!ctype_digit((string)$qty) || (int)$qty < 1) flash('danger', 'Quantity must be a whole number of 1 or more.');
  else {
    $pdo->beginTransaction();
    $b = q('SELECT b.*,p.name,p.cost_price FROM batches b JOIN products p ON p.id=b.product_id WHERE b.id=? FOR UPDATE', [$bid])->fetch();
    if (!$b) { $pdo->rollBack(); flash('danger', 'Batch not found.'); }
    elseif ((int)$qty > (int)$b['qty_remaining']) { $pdo->rollBack(); flash('danger', 'Only ' . (int)$b['qty_remaining'] . ' left in that batch.'); }
    else {
      $amt = round((int)$qty * (float)$b['cost_price'], 2);
      q('UPDATE batches SET qty_remaining=qty_remaining-? WHERE id=?', [(int)$qty, $bid]);
      q('INSERT INTO losses(product_id,qty,reason,amount) VALUES(?,?,?,?)', [$b['product_id'], (int)$qty, $why, $amt]);
      $pdo->commit();
      audit("stock-out {$b['name']} batch {$b['batch_no']} qty " . (int)$qty . " ($why)");
      run_checks();
      flash('success', 'Recorded loss of ' . (int)$qty . ' &times; <b>' . h($b['name']) . '</b> (' . money($amt) . ').');
    }
  }
  go('stockout.php');
}
$pre = (int)($_GET['batch'] ?? 0);
$batches = q('SELECT b.*,p.name,p.unit FROM batches b JOIN products p ON p.id=b.product_id WHERE b.qty_remaining>0 ORDER BY b.expiry IS NULL, b.expiry, b.id')->fetchAll();
$losses = q('SELECT l.*,p.name FROM losses l LEFT JOIN products p ON p.id=l.product_id ORDER BY l.id DESC LIMIT 30')->fetchAll();
$lossTotal = q('SELECT COALESCE(SUM(amount),0) s FROM losses')->fetch()['s'];
top('Stock-Out / Losses', 'Write off expired, damaged or spoiled stock. Normal sales are recorded on the Sales page.'); ?>
<div class="row g-4">
  <div class="col-lg-4"><div class="ag-card ag-card-form">
    <div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-box-arrow-up"></i> Record a loss</h2></div>
    <?php if (!$batches): echo empty_state('bi-box-seam', 'No stock', 'There are no batches with stock left.'); else: ?>
    <form method="post"><?= csrf_field() ?>
      <label class="form-label">Batch</label>
      <select class="form-select mb-2" name="batch_id" required><option value="">Choose&hellip;</option>
        <?php foreach ($batches as $b): ?><option value="<?= (int)$b['id'] ?>" <?= $pre === (int)$b['id'] ? 'selected' : '' ?>><?= h($b['name']) ?> &middot; batch <?= h($b['batch_no']) ?> &middot; <?= (int)$b['qty_remaining'] ?> left<?= $b['expiry'] ? ' &middot; exp ' . h(date('M j, Y', strtotime($b['expiry']))) : '' ?></option><?php endforeach; ?></select>
      <div class="row g-2 mb-3"><div class="col-6"><label class="form-label">Quantity</label><input class="form-control" type="number" name="qty" min="1" step="1" required></div>
        <div class="col-6"><label class="form-label">Reason</label><select class="form-select" name="reason" required><option value="expired">Expired</option><option value="damaged">Damaged</option><option value="spoiled">Spoiled</option></select></div></div>
      <button class="btn btn-danger w-100" onclick="return confirm('Remove this stock and record it as a loss?')"><i class="bi bi-check2 me-1"></i>Record loss</button>
    </form><?php endif; ?>
  </div></div>
  <div class="col-lg-8">
    <div class="ag-card mb-4">
      <div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-stack"></i> Batches in stock <span class="ag-badge ag-badge-muted">first to expire on top</span></h2></div>
      <?php if (!$batches): echo empty_state('bi-box-seam', 'No stock', 'Nothing to show.'); else: ?>
      <div class="table-responsive"><table class="table"><thead><tr><th>Product</th><th>Batch</th><th class="ag-num">Left</th><th>Expiry</th><th></th></tr></thead><tbody>
      <?php foreach ($batches as $b):
        $exp = $b['expiry'] && $b['expiry'] < date('Y-m-d'); $soon = !$exp && $b['expiry'] && $b['expiry'] <= date('Y-m-d', strtotime('+30 day')); ?>
        <tr class="<?= $exp ? 'ag-row-danger' : ($soon ? 'ag-row-warn' : '') ?>"><td class="ag-strong"><?= h($b['name']) ?></td><td><?= h($b['batch_no']) ?></td><td class="ag-num"><?= (int)$b['qty_remaining'] ?> <?= h($b['unit']) ?></td>
          <td class="text-nowrap"><?= nice_date($b['expiry'], false) ?> <?php if ($exp): ?><span class="ag-badge ag-badge-danger">Expired</span><?php elseif ($soon): ?><span class="ag-badge ag-badge-warn">Soon</span><?php endif; ?></td>
          <td class="text-end"><a class="btn btn-sm btn-light" href="stockout.php?batch=<?= (int)$b['id'] ?>">Write off</a></td></tr>
      <?php endforeach; ?></tbody></table></div><?php endif; ?>
    </div>
    <div class="ag-card">
      <div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-trash3"></i> Loss history</h2><span class="ag-badge ag-badge-danger">Total <?= money($lossTotal) ?></span></div>
      <?php if (!$losses): echo empty_state('bi-check2-circle', 'No losses recorded', 'Good news.'); else: ?>
      <div class="table-responsive"><table class="table"><thead><tr><th>Date</th><th>Product</th><th>Reason</th><th class="ag-num">Qty</th><th class="ag-num">Cost</th></tr></thead><tbody>
      <?php foreach ($losses as $l): ?><tr><td class="text-nowrap small"><?= nice_date($l['created_at']) ?></td><td class="ag-strong"><?= h($l['name'] ?: 'Deleted product') ?></td><td><?= h(ucfirst($l['reason'])) ?></td><td class="ag-num"><?= (int)$l['qty'] ?></td><td class="ag-num"><?= money($l['amount']) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
    </div>
  </div>
</div>
<?php bottom();
