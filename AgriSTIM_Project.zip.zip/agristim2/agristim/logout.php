<?php require 'config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!empty($_SESSION['u'])) audit('logout');
  $_SESSION = []; session_destroy();
  go('login.php');
}
need(); head_tags('Log out'); ?>
</head><body class="ag-auth"><div class="ag-auth-form" style="min-height:100vh"><div class="ag-auth-card card p-4 text-center">
<div class="ag-logo mx-auto mb-3">&#127806;</div>
<h4 class="ag-display mb-1">Log out?</h4>
<p class="text-muted small">Signed in as <b><?= h(me()['full_name']) ?></b> (<?= h(me()['role']) ?>)</p>
<form method="post" class="d-grid gap-2"><?= csrf_field() ?>
<button class="btn btn-danger">Yes, log out</button>
<a class="btn btn-outline-secondary" href="index.php">Cancel</a>
</form></div></div></body></html>
