<?php // ESP32 posts JSON: {"key":"...","device_id":"ESP32-FRIDGE","temp":5.4,"humidity":60}
define('NO_SESSION', true);   // sensors don't log in; skip sessions so the sessions folder doesn't fill up
require '../config.php'; header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('{"error":"use POST"}'); }
$d = json_decode(file_get_contents('php://input'), true);
if (!is_array($d) || !hash_equals(SENSOR_KEY, (string)($d['key'] ?? ''))) { http_response_code(401); exit('{"error":"unauthorized"}'); }
$u = q('SELECT * FROM storage_units WHERE device_id=?', [(string)($d['device_id'] ?? '')])->fetch();
if (!$u) { http_response_code(404); exit('{"error":"unknown device_id - add it on the Temperature page"}'); }
if (!is_numeric($d['temp'] ?? null) || $d['temp'] < -60 || $d['temp'] > 100) { http_response_code(400); exit('{"error":"bad temperature"}'); }
$t = round((float)$d['temp'], 2); $hum = is_numeric($d['humidity'] ?? null) ? round((float)$d['humidity'], 2) : null;
q('INSERT INTO temp_logs(unit_id,temp_c,humidity) VALUES(?,?,?)', [$u['id'], $t, $hum]);
auto_resolve('offline', $u['id'], 'Sensor back online');
$out = $t < $u['min_c'] || $t > $u['max_c'];
if ($out) alert_once('temp', $u['id'], "{$u['name']}: {$t}°C is outside " . temp($u['min_c']) . '–' . temp($u['max_c']) . '°C');
echo json_encode(['ok' => true, 'out_of_range' => $out]);
