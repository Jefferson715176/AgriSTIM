<?php require '../config.php'; header('Content-Type: application/json');
if (empty($_SESSION['u']['id'])) { http_response_code(401); exit('{"error":"login required"}'); }
session_write_close();
$out = [];
foreach (q('SELECT * FROM storage_units ORDER BY id') as $u) {
  $s = array_reverse(q('SELECT temp_c v, humidity hm, logged_at t FROM temp_logs WHERE unit_id=? ORDER BY logged_at DESC LIMIT 60', [$u['id']])->fetchAll());
  $last  = $s ? end($s) : null;
  $stale = !$last || strtotime($last['t']) < time() - 600;
  $isOut = $last && ($last['v'] < $u['min_c'] || $last['v'] > $u['max_c']);
  $out[] = ['name' => $u['name'], 'min' => temp($u['min_c']), 'max' => temp($u['max_c']),
    'temp' => $last ? temp($last['v']) : null, 'humidity' => $last && $last['hm'] !== null ? temp($last['hm']) : null,
    'last' => $last ? date('M j, g:i A', strtotime($last['t'])) : null,
    'status' => $stale ? 'Offline' : ($isOut ? 'Out of range' : 'Normal'), 'out' => $stale || $isOut,
    'series' => array_map(function ($r) { return ['v' => (float)$r['v'], 't' => $r['t']]; }, $s)];
}
echo json_encode($out);
