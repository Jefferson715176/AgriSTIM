<?php require 'config.php'; need();
$own = is_owner();
$v = ($_GET['v'] ?? '') === 'prices' ? 'prices' : 'items';
function pm($x) { return $x === null || $x === '' ? '&mdash;' : money($x); }
function num($k) { $x = post($k); return ($x !== '' && is_numeric($x) && (float)$x >= 0) ? round((float)$x, 2) : null; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!$own) { flash('danger', 'Only the owner can change products.'); go('products.php'); }
  $do = post('do'); $id = (int)post('id');
  if ($do === 'archive' || $do === 'restore') {
    $p = q('SELECT * FROM products WHERE id=?', [$id])->fetch();
    if ($p) { q('UPDATE products SET archived=? WHERE id=?', [$do === 'archive' ? 1 : 0, $id]); audit("$do product {$p['name']}"); flash('success', 'Product ' . ($do === 'archive' ? 'archived' : 'restored') . '.'); }
    go('products.php' . ($do === 'restore' ? '?arch=1' : ''));
  }
  if ($do === 'save') {
    $name = post('name'); $cat = post('category'); $unit = post('unit');
    $cost = num('cost_price'); $ret = num('retail_price'); $bulk = num('bulk_price'); $ro = post('reorder_level');
    $err = '';
    if ($name === '' || mb_strlen($name) > 120) $err = 'Please enter a product name (up to 120 characters).';
    elseif ($cat === '') $err = 'Please choose a category.';
    elseif ($unit === '' || mb_strlen($unit) > 20) $err = 'Please enter a unit (sack, bottle, piece...).';
    elseif ($cost === null || $ret === null || $bulk === null) $err = 'Prices must be numbers that are not negative.';
    elseif (!ctype_digit((string)$ro)) $err = 'Reorder level must be a whole number, 0 or more.';
    elseif (q('SELECT 1 FROM products WHERE name=? AND archived=0 AND id<>?', [$name, $id])->fetch()) $err = 'A product with that name already exists.';
    if ($err) { flash('danger', $err); go('products.php?' . ($id ? "edit=$id" : 'add=1')); }
    if ($id) {
      $old = q('SELECT * FROM products WHERE id=?', [$id])->fetch();
      q('UPDATE products SET name=?,category=?,unit=?,cost_price=?,retail_price=?,bulk_price=?,reorder_level=? WHERE id=?', [$name, $cat, $unit, $cost, $ret, $bulk, (int)$ro, $id]);
      if ($old && ((float)$old['cost_price'] != $cost || (float)$old['retail_price'] != $ret || (float)$old['bulk_price'] != $bulk))
        audit("price change $name cost {$old['cost_price']}->$cost retail {$old['retail_price']}->$ret bulk {$old['bulk_price']}->$bulk");
      audit("edit product $name"); flash('success', 'Product saved.');
    } else {
      q('INSERT INTO products(name,category,unit,cost_price,retail_price,bulk_price,reorder_level) VALUES(?,?,?,?,?,?,?)', [$name, $cat, $unit, $cost, $ret, $bulk, (int)$ro]);
      audit("add product $name"); flash('success', 'Product <b>' . h($name) . '</b> added.');
    }
    run_checks(); go('products.php');
  }
  go('products.php');
}

$k = trim($_GET['k'] ?? ''); $c = trim($_GET['c'] ?? ''); $arch = !empty($_GET['arch']) ? 1 : 0;
$edit = null;
if ($own && !empty($_GET['edit'])) $edit = q('SELECT * FROM products WHERE id=?', [(int)$_GET['edit']])->fetch();
$showForm = $own && $v === 'items' && ($edit || !empty($_GET['add']));
$cats = categories();

if ($v === 'items') {
  $w = 'p.archived=?'; $p = [$arch];
  if ($c !== '') { $w .= ' AND p.category=?'; $p[] = $c; }
  if ($k !== '') { $w .= ' AND p.name LIKE ?'; $p[] = "%$k%"; }
  $rows = q("SELECT p.*, COALESCE((SELECT SUM(qty_remaining) FROM batches WHERE product_id=p.id),0) stock FROM products p WHERE $w ORDER BY p.name", $p)->fetchAll();
} else {
  $w = '1=1'; $p = [];
  if ($c !== '') { $w .= ' AND category=?'; $p[] = $c; }
  if ($k !== '') { $w .= ' AND (product_name LIKE ? OR brand LIKE ? OR variant LIKE ?)'; array_push($p, "%$k%", "%$k%", "%$k%"); }
  $rows = q("SELECT DISTINCT category,brand,product_name,variant,price_per_kilo,price_per_sack,price_half_sack,price_per_piece,price_tie_by_10s,needs_review
             FROM price_list WHERE $w ORDER BY category,brand,product_name,variant LIMIT 400", $p)->fetchAll();
  $plcats = array_column(q('SELECT DISTINCT category FROM price_list ORDER BY category')->fetchAll(), 'category');
}
$actions = $own && $v === 'items' ? '<a class="btn btn-success" href="products.php?add=1"><i class="bi bi-plus-lg me-1"></i>New product</a>' : '';
top($own ? 'Products & Prices' : 'Inventory', $own ? 'Manage products, selling prices and reorder levels.' : 'Products and how many are in stock.', $actions); ?>

<div class="ag-pills mb-3"><a class="<?= $v === 'items' ? 'active' : '' ?>" href="products.php">Products</a><a class="<?= $v === 'prices' ? 'active' : '' ?>" href="products.php?v=prices">Supplier price list</a></div>

<div class="row g-4">
<?php if ($showForm): $f = $edit ?: ['id' => 0, 'name' => '', 'category' => '', 'unit' => '', 'cost_price' => '', 'retail_price' => '', 'bulk_price' => '', 'reorder_level' => 5]; ?>
  <div class="col-lg-4"><div class="ag-card ag-card-form">
    <div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-<?= $edit ? 'pencil' : 'plus-circle' ?>"></i> <?= $edit ? 'Edit product' : 'New product' ?></h2><a class="small" href="products.php">Close</a></div>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
      <label class="form-label">Name</label><input class="form-control mb-2" name="name" maxlength="120" value="<?= h($f['name']) ?>" required>
      <label class="form-label">Category</label><select class="form-select mb-2" name="category" required><option value="">Choose&hellip;</option>
        <?php foreach ($cats as $cn): ?><option <?= $cn === $f['category'] ? 'selected' : '' ?>><?= h($cn) ?></option><?php endforeach; ?></select>
      <div class="row g-2 mb-2"><div class="col-6"><label class="form-label">Unit</label><input class="form-control" name="unit" maxlength="20" placeholder="sack, bottle" value="<?= h($f['unit']) ?>" required></div>
        <div class="col-6"><label class="form-label">Reorder at</label><input class="form-control" type="number" min="0" step="1" name="reorder_level" value="<?= h($f['reorder_level']) ?>" required></div></div>
      <div class="row g-2 mb-3"><div class="col-4"><label class="form-label">Cost</label><input class="form-control" type="number" min="0" step="0.01" name="cost_price" value="<?= h($f['cost_price']) ?>" required></div>
        <div class="col-4"><label class="form-label">Retail</label><input class="form-control" type="number" min="0" step="0.01" name="retail_price" value="<?= h($f['retail_price']) ?>" required></div>
        <div class="col-4"><label class="form-label">Bulk</label><input class="form-control" type="number" min="0" step="0.01" name="bulk_price" value="<?= h($f['bulk_price']) ?>" required></div></div>
      <button class="btn btn-success w-100"><i class="bi bi-check2 me-1"></i>Save product</button>
    </form>
  </div></div>
<?php endif; ?>
  <div class="<?= $showForm ? 'col-lg-8' : 'col-12' ?>"><div class="ag-card">
    <form class="row g-2 mb-3"><?php if ($v === 'prices'): ?><input type="hidden" name="v" value="prices"><?php endif; ?>
      <div class="col-sm-5"><div class="input-group"><span class="input-group-text"><i class="bi bi-search"></i></span><input class="form-control" name="k" value="<?= h($k) ?>" placeholder="Search&hellip;"></div></div>
      <div class="col-sm-3"><select class="form-select" name="c"><option value="">All categories</option>
        <?php foreach ($v === 'items' ? $cats : $plcats as $cn): ?><option <?= $cn === $c ? 'selected' : '' ?>><?= h($cn) ?></option><?php endforeach; ?></select></div>
      <?php if ($v === 'items'): ?><div class="col-auto d-flex align-items-center"><div class="form-check"><input class="form-check-input" type="checkbox" name="arch" value="1" id="arch" <?= $arch ? 'checked' : '' ?>><label class="form-check-label" for="arch">Archived</label></div></div><?php endif; ?>
      <div class="col-auto"><button class="btn btn-success">Filter</button></div>
    </form>
    <?php if (!$rows): echo empty_state('bi-box-seam', 'Nothing found', 'Try a different search or filter.'); elseif ($v === 'items'): ?>
    <div class="table-responsive"><table class="table"><thead><tr><th>Product</th><th>Category</th><th class="ag-num">In stock</th>
      <?php if ($own): ?><th class="ag-num">Cost</th><?php endif; ?><th class="ag-num">Retail</th><th class="ag-num">Bulk</th><th class="ag-num">Reorder</th><?php if ($own): ?><th></th><?php endif; ?></tr></thead><tbody>
    <?php foreach ($rows as $r): $lowS = (int)$r['stock'] <= (int)$r['reorder_level']; ?>
      <tr class="<?= $r['archived'] ? 'ag-row-muted' : ($lowS ? 'ag-row-warn' : '') ?>">
        <td class="ag-strong"><?= h($r['name']) ?><span class="ag-sub">per <?= h($r['unit']) ?></span></td><td><?= h($r['category']) ?></td>
        <td class="ag-num"><?= (int)$r['stock'] ?> <?php if (!$r['archived'] && $lowS): ?><span class="ag-badge ag-badge-warn">Low</span><?php endif; ?></td>
        <?php if ($own): ?><td class="ag-num"><?= pm($r['cost_price']) ?></td><?php endif; ?>
        <td class="ag-num"><?= pm($r['retail_price']) ?></td><td class="ag-num"><?= pm($r['bulk_price']) ?></td><td class="ag-num"><?= (int)$r['reorder_level'] ?></td>
        <?php if ($own): ?><td class="text-end text-nowrap">
          <?php if (!$r['archived']): ?><a class="btn btn-sm btn-light" href="products.php?edit=<?= (int)$r['id'] ?>"><i class="bi bi-pencil"></i></a>
            <form method="post" class="d-inline" data-confirm="Archive <?= h($r['name']) ?>? It will be hidden from sales and stock-in."><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn btn-sm btn-outline-danger" name="do" value="archive" title="Archive"><i class="bi bi-archive"></i></button></form>
          <?php else: ?><form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn btn-sm btn-outline-success" name="do" value="restore"><i class="bi bi-arrow-counterclockwise"></i> Restore</button></form><?php endif; ?></td><?php endif; ?>
      </tr>
    <?php endforeach; ?></tbody></table></div>
    <?php else: ?>
    <p class="text-muted small">Reference prices from the supplier list. Rows marked <span class="ag-badge ag-badge-warn">Check</span> need review. Showing up to 400 rows.</p>
    <div class="table-responsive"><table class="table"><thead><tr><th>Category</th><th>Brand</th><th>Product</th><th>Variant</th><th class="ag-num">Per kilo</th><th class="ag-num">Per sack</th><th class="ag-num">Half sack</th><th class="ag-num">Per piece</th><th class="ag-num">Tie by 10s</th><th></th></tr></thead><tbody>
    <?php foreach ($rows as $r): ?><tr><td><?= h($r['category']) ?></td><td><?= h($r['brand']) ?></td><td class="ag-strong"><?= h($r['product_name']) ?></td><td><?= h($r['variant']) ?></td>
      <td class="ag-num"><?= pm($r['price_per_kilo']) ?></td><td class="ag-num"><?= pm($r['price_per_sack']) ?></td><td class="ag-num"><?= pm($r['price_half_sack']) ?></td><td class="ag-num"><?= pm($r['price_per_piece']) ?></td><td class="ag-num"><?= pm($r['price_tie_by_10s']) ?></td>
      <td><?php if ($r['needs_review']): ?><span class="ag-badge ag-badge-warn">Check</span><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div>
    <?php endif; ?>
  </div></div>
</div>
<?php bottom();
