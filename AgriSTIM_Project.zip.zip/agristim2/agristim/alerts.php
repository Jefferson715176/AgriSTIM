<?php require 'config.php'; need(); run_checks();
$s = in_array($_GET['s'] ?? '', ['active', 'resolved', 'all']) ? $_GET['s'] : 'active';
$t = in_array($_GET['t'] ?? '', ['temp', 'offline', 'low_stock', 'expiry']) ? $_GET['t'] : '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = (int)post('id'); $st = post('do') === 'resolve' ? 'resolved' : 'ack'; $rm = post('remarks');
  if ($st === 'resolved' && $rm === '') flash('danger', 'Please write the action taken before resolving.');
  else {
    if ($rm !== '') q('UPDATE alerts SET status=?,remarks=? WHERE id=?', [$st, $rm, $id]); else q("UPDATE alerts SET status=? WHERE id=? AND status='open'", [$st, $id]);
    audit("alert #$id $st"); flash('success', $st === 'resolved' ? 'Alert resolved.' : 'Alert acknowledged.');
  }
  go("alerts.php?s=$s&t=$t");
}
$where = $s === 'resolved' ? "status='resolved'" : ($s === 'all' ? '1=1' : "status<>'resolved'");
$p = []; if ($t) { $where .= ' AND type=?'; $p[] = $t; }
$rows = q("SELECT * FROM alerts WHERE $where ORDER BY created_at DESC, id DESC LIMIT 200", $p)->fetchAll();
$counts = []; foreach (q("SELECT type,COUNT(*) c FROM alerts WHERE status<>'resolved' GROUP BY type") as $r) $counts[$r['type']] = $r['c'];
top('Alerts & Notifications', 'Temperature problems, offline sensors, low stock and expiring batches.'); ?>
<div class="d-flex flex-wrap gap-2 justify-content-between mb-3">
  <div class="ag-pills"><?php foreach (['active' => 'Active', 'resolved' => 'Resolved', 'all' => 'All'] as $k => $v) echo "<a class='" . ($s === $k ? 'active' : '') . "' href='?s=$k&t=$t'>$v</a>"; ?></div>
  <div class="ag-pills"><a class="<?= $t === '' ? 'active' : '' ?>" href="?s=<?= $s ?>">All types</a>
    <?php foreach (['temp', 'offline', 'low_stock', 'expiry'] as $k) echo "<a class='" . ($t === $k ? 'active' : '') . "' href='?s=$s&t=$k'>" . h(alert_label($k)) . (!empty($counts[$k]) ? " <span class='ag-badge ag-badge-warn ms-1'>{$counts[$k]}</span>" : '') . '</a>'; ?></div>
</div>
<div class="ag-card">
  <?php if (!$rows): echo empty_state('bi-check2-circle', $s === 'active' ? 'All clear' : 'No alerts', $s === 'active' ? 'There are no active alerts right now.' : 'Nothing to show for this filter.'); else: ?>
  <div class="table-responsive"><table class="table"><thead><tr><th>Date</th><th>Type</th><th>Message</th><th>Status</th><th style="min-width:340px">Remarks / action taken</th></tr></thead><tbody>
  <?php foreach ($rows as $a): ?><tr>
    <td class="text-nowrap small"><?= nice_date($a['created_at']) ?></td><td><?= alert_badge($a['type']) ?></td><td class="ag-strong"><?= h($a['message']) ?></td><td><?= status_badge($a['status']) ?></td>
    <td><?php if ($a['status'] !== 'resolved'): ?>
      <form method="post" class="d-flex gap-1"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $a['id'] ?>">
        <input class="form-control form-control-sm" name="remarks" placeholder="Action taken&hellip;" value="<?= h($a['remarks']) ?>">
        <?php if ($a['status'] === 'open'): ?><button class="btn btn-sm btn-light" name="do" value="ack" title="Acknowledge"><i class="bi bi-eye"></i></button><?php endif; ?>
        <button class="btn btn-sm btn-success text-nowrap" name="do" value="resolve"><i class="bi bi-check2"></i> Resolve</button></form>
    <?php else: ?><span class="text-muted"><?= h($a['remarks'] ?: '—') ?></span><?php endif; ?></td>
  </tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</div>
<?php bottom();
