<?php require 'config.php'; need(); run_checks();

$products = (int)q('SELECT COUNT(*) c FROM products WHERE archived=0')->fetch()['c'];
$low      = (int)q("SELECT COUNT(*) c FROM alerts WHERE type='low_stock' AND status<>'resolved'")->fetch()['c'];
$expiring = (int)q('SELECT COUNT(*) c FROM batches WHERE qty_remaining>0 AND expiry IS NOT NULL AND expiry <= CURDATE() + INTERVAL 30 DAY')->fetch()['c'];
$today    = q('SELECT COALESCE(SUM(total),0) s, COUNT(*) n FROM sales WHERE DATE(created_at)=CURDATE()')->fetch();
$value    = q('SELECT COALESCE(SUM(b.qty_remaining*p.cost_price),0) v FROM batches b JOIN products p ON p.id=b.product_id WHERE p.archived=0')->fetch()['v'];

// last 7 days of sales for the chart
$days = []; for ($i = 6; $i >= 0; $i--) $days[date('Y-m-d', strtotime("-$i day"))] = 0;
foreach (q('SELECT DATE(created_at) d, SUM(total) s FROM sales WHERE created_at >= CURDATE() - INTERVAL 6 DAY GROUP BY DATE(created_at)') as $r) if (isset($days[$r['d']])) $days[$r['d']] = (float)$r['s'];

$alerts = q("SELECT * FROM alerts WHERE status<>'resolved' ORDER BY created_at DESC, id DESC LIMIT 6")->fetchAll();
$near = q('SELECT b.batch_no,b.qty_remaining,b.expiry,p.name FROM batches b JOIN products p ON p.id=b.product_id
           WHERE b.qty_remaining>0 AND b.expiry IS NOT NULL AND b.expiry <= CURDATE() + INTERVAL 30 DAY ORDER BY b.expiry LIMIT 6')->fetchAll();

function stat_card($href, $tone, $icon, $label, $value) {
  return "<div class='col-6 col-xl-3'><a class='ag-stat-link' href='$href'><div class='card ag-stat ag-tone-$tone'><div class='ag-stat-icon'><i class='bi $icon'></i></div>"
    . "<div><div class='ag-stat-label'>$label</div><div class='ag-stat-value'>$value</div></div></div></a></div>";
}
top('Dashboard', 'Welcome back, ' . h(me()['full_name']) . '. Here is how ' . h(STORE_NAME) . ' is doing today.'); ?>

<div class="row g-3 mb-4">
  <?= stat_card('sales.php?v=history', 'green', 'bi-cash-coin', 'Sales today', money($today['s']) . '<span class="ag-sub">' . (int)$today['n'] . ' sale(s)</span>') ?>
  <?= stat_card('products.php', 'green', 'bi-box-seam', 'Active products', $products . (is_owner() ? '<span class="ag-sub">Stock value ' . money($value) . '</span>' : '')) ?>
  <?= stat_card('alerts.php?t=low_stock', 'wheat', 'bi-exclamation-triangle', 'Low stock', $low) ?>
  <?= stat_card('stockout.php', 'soil', 'bi-calendar-x', 'Expiring in 30 days', $expiring) ?>
</div>

<h2 class="ag-card-title mb-3"><i class="bi bi-thermometer-half"></i> Storage temperatures</h2>
<div class="row g-3 mb-4" id="unitCards"><div class="col-12 text-muted small">Loading sensors&hellip;</div></div>

<div class="row g-4">
  <div class="col-lg-7">
    <div class="ag-card mb-4">
      <div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-graph-up"></i> Sales, last 7 days</h2></div>
      <div style="height:240px"><canvas id="salesChart"></canvas></div>
    </div>
    <div class="ag-card">
      <div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-calendar-x"></i> Expiring or expired batches</h2><a class="small" href="stockout.php">Manage</a></div>
      <?php if (!$near): echo empty_state('bi-check2-circle', 'Nothing expiring soon', 'No batch expires within 30 days.'); else: ?>
      <div class="table-responsive"><table class="table"><thead><tr><th>Product</th><th>Batch</th><th class="ag-num">Qty</th><th>Expiry</th></tr></thead><tbody>
      <?php foreach ($near as $b): $exp = $b['expiry'] < date('Y-m-d'); ?>
        <tr class="<?= $exp ? 'ag-row-danger' : 'ag-row-warn' ?>"><td class="ag-strong"><?= h($b['name']) ?></td><td><?= h($b['batch_no']) ?></td><td class="ag-num"><?= (int)$b['qty_remaining'] ?></td>
          <td><?= nice_date($b['expiry'], false) ?> <span class="ag-badge <?= $exp ? 'ag-badge-danger' : 'ag-badge-warn' ?>"><?= $exp ? 'Expired' : 'Soon' ?></span></td></tr>
      <?php endforeach; ?></tbody></table></div><?php endif; ?>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="ag-card">
      <div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-bell"></i> Active alerts</h2><a class="small" href="alerts.php">See all</a></div>
      <?php if (!$alerts): echo empty_state('bi-check2-circle', 'All clear', 'There are no active alerts right now.'); else: foreach ($alerts as $a): ?>
        <div class="ag-alert-item"><div class="ag-alert-body">
          <?= alert_badge($a['type']) ?> <?= status_badge($a['status']) ?>
          <div class="ag-alert-msg"><?= h($a['message']) ?></div><div class="ag-alert-time"><?= nice_date($a['created_at']) ?></div>
          <form method="post" action="alerts.php" class="d-flex gap-1 mt-2"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
            <input class="form-control form-control-sm" name="remarks" placeholder="Action taken&hellip;" value="<?= h($a['remarks']) ?>">
            <?php if ($a['status'] === 'open'): ?><button class="btn btn-sm btn-light" name="do" value="ack" title="Acknowledge"><i class="bi bi-eye"></i></button><?php endif; ?>
            <button class="btn btn-sm btn-success text-nowrap" name="do" value="resolve"><i class="bi bi-check2"></i> Resolve</button></form>
        </div></div>
      <?php endforeach; endif; ?>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
  agLive('unitCards', {chart: false});
  var d = <?= json_encode(array_keys($days)) ?>, v = <?= json_encode(array_values($days)) ?>;
  new Chart(document.getElementById('salesChart'), {
    type: 'bar',
    data: {labels: d.map(function (x) { return new Date(x + 'T00:00:00').toLocaleDateString(undefined, {month: 'short', day: 'numeric'}); }),
           datasets: [{data: v, backgroundColor: '#2f7a45', borderRadius: 6}]},
    options: {maintainAspectRatio: false, plugins: {legend: {display: false}}, scales: {y: {beginAtZero: true}}}
  });
});
</script>
<?php bottom();
