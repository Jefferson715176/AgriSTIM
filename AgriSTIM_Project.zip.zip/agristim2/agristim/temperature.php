<?php require 'config.php'; need(); run_checks();
$own = is_owner();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!$own) { flash('danger', 'Only the owner can change storage units.'); go('temperature.php'); }
  $do = post('do'); $id = (int)post('id');
  if ($do === 'save') {
    $name = post('name'); $dev = post('device_id'); $min = post('min_c'); $max = post('max_c'); $err = '';
    if ($name === '' || mb_strlen($name) > 80) $err = 'Please enter a unit name.';
    elseif ($dev === '' || mb_strlen($dev) > 40 || !preg_match('/^[A-Za-z0-9_.-]+$/', $dev)) $err = 'Device ID may only use letters, numbers, dash and underscore.';
    elseif (!is_numeric($min) || !is_numeric($max)) $err = 'Minimum and maximum must be numbers.';
    elseif ((float)$min >= (float)$max) $err = 'Minimum temperature must be lower than the maximum.';
    elseif (q('SELECT 1 FROM storage_units WHERE device_id=? AND id<>?', [$dev, $id])->fetch()) $err = 'That Device ID is already used by another unit.';
    if ($err) flash('danger', $err);
    elseif ($id) { q('UPDATE storage_units SET name=?,device_id=?,min_c=?,max_c=? WHERE id=?', [$name, $dev, $min, $max, $id]); audit("storage unit updated $name"); flash('success', 'Storage unit saved.'); }
    else { q('INSERT INTO storage_units(name,device_id,min_c,max_c) VALUES(?,?,?,?)', [$name, $dev, $min, $max]); audit("storage unit added $name"); flash('success', 'Storage unit added.'); }
  }
  if ($do === 'delete') {
    $u = q('SELECT * FROM storage_units WHERE id=?', [$id])->fetch();
    if ($u && q('SELECT 1 FROM batches WHERE unit_id=? AND qty_remaining>0', [$id])->fetch()) flash('danger', 'This unit still holds stock. Move or sell it first.');
    elseif ($u) {
      q('DELETE FROM temp_logs WHERE unit_id=?', [$id]); q("DELETE FROM alerts WHERE type IN ('temp','offline') AND ref_id=?", [$id]);
      q('UPDATE batches SET unit_id=NULL WHERE unit_id=?', [$id]); q('DELETE FROM storage_units WHERE id=?', [$id]);
      audit("storage unit deleted {$u['name']}"); flash('success', 'Storage unit deleted.');
    }
  }
  go('temperature.php');
}
$units = q('SELECT * FROM storage_units ORDER BY id')->fetchAll();
$f = (int)($_GET['u'] ?? 0);
$logs = q('SELECT t.*,u.name,u.min_c,u.max_c FROM temp_logs t JOIN storage_units u ON u.id=t.unit_id' . ($f ? ' WHERE t.unit_id=?' : '') . ' ORDER BY t.logged_at DESC LIMIT 40', $f ? [$f] : [])->fetchAll();
top('Temperature Monitoring', 'Live readings from the ESP32 sensors. A sensor silent for 10 minutes is shown as Offline.'); ?>
<div class="row g-3 mb-4" id="unitCards"><div class="col-12 text-muted small">Loading sensors&hellip;</div></div>

<div class="row g-4">
  <div class="col-lg-<?= $own ? '7' : '12' ?>"><div class="ag-card">
    <div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-table"></i> Recent readings</h2>
      <form class="d-flex gap-1"><select class="form-select form-select-sm" name="u" onchange="this.form.submit()"><option value="0">All units</option>
        <?php foreach ($units as $u): ?><option value="<?= (int)$u['id'] ?>" <?= $f === (int)$u['id'] ? 'selected' : '' ?>><?= h($u['name']) ?></option><?php endforeach; ?></select></form></div>
    <?php if (!$logs): echo empty_state('bi-thermometer', 'No readings yet', 'Readings appear here once an ESP32 sends data to api/sensor.php.'); else: ?>
    <div class="table-responsive"><table class="table"><thead><tr><th>Time</th><th>Unit</th><th class="ag-num">Temp</th><th class="ag-num">Humidity</th><th>Status</th></tr></thead><tbody>
    <?php foreach ($logs as $l): $out = $l['temp_c'] < $l['min_c'] || $l['temp_c'] > $l['max_c']; ?>
      <tr class="<?= $out ? 'ag-row-danger' : '' ?>"><td class="text-nowrap small"><?= nice_date($l['logged_at']) ?></td><td><?= h($l['name']) ?></td><td class="ag-num"><?= temp($l['temp_c']) ?> &deg;C</td><td class="ag-num"><?= $l['humidity'] === null ? '&mdash;' : temp($l['humidity']) . '%' ?></td>
        <td><span class="ag-badge <?= $out ? 'ag-badge-danger' : 'ag-badge-ok' ?>"><?= $out ? 'Out of range' : 'Normal' ?></span></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
  </div></div>

<?php if ($own): ?>
  <div class="col-lg-5"><div class="ag-card ag-card-form">
    <div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-snow"></i> Storage units</h2></div>
    <?php foreach ($units as $u): ?>
      <form method="post" class="border rounded-3 p-2 mb-2"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
        <div class="row g-1 mb-1"><div class="col-7"><input class="form-control form-control-sm" name="name" value="<?= h($u['name']) ?>" maxlength="80" required></div><div class="col-5"><input class="form-control form-control-sm" name="device_id" value="<?= h($u['device_id']) ?>" maxlength="40" required></div></div>
        <div class="d-flex gap-1"><input class="form-control form-control-sm" type="number" step="0.1" name="min_c" value="<?= h(temp($u['min_c'])) ?>" required title="Min &deg;C"><input class="form-control form-control-sm" type="number" step="0.1" name="max_c" value="<?= h(temp($u['max_c'])) ?>" required title="Max &deg;C">
          <button class="btn btn-sm btn-success"><i class="bi bi-check2"></i></button>
          <button class="btn btn-sm btn-outline-danger" name="do" value="delete" formnovalidate onclick="return confirm('Delete this unit and all its readings?')"><i class="bi bi-trash"></i></button></div>
      </form>
    <?php endforeach; ?>
    <h6 class="mt-3">Add a unit</h6>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" value="0">
      <div class="row g-1 mb-1"><div class="col-7"><input class="form-control form-control-sm" name="name" placeholder="Name" maxlength="80" required></div><div class="col-5"><input class="form-control form-control-sm" name="device_id" placeholder="Device ID" maxlength="40" required></div></div>
      <div class="d-flex gap-1"><input class="form-control form-control-sm" type="number" step="0.1" name="min_c" placeholder="Min &deg;C" required><input class="form-control form-control-sm" type="number" step="0.1" name="max_c" placeholder="Max &deg;C" required><button class="btn btn-sm btn-success text-nowrap"><i class="bi bi-plus-lg"></i> Add</button></div>
    </form>
    <p class="text-muted small mt-2 mb-0">The Device ID must match <code>DEVICE_ID</code> in the ESP32 sketch.</p>
  </div></div>
<?php endif; ?>
</div>
<script>document.addEventListener('DOMContentLoaded', function () { agLive('unitCards', {chart: true}); });</script>
<?php bottom();
