<?php
/* =========================================================================
   AgriSTIM - RJM Agrivet Inventory & Storage Monitoring
   SETTINGS: change these to match your XAMPP / MySQL setup.
   ========================================================================= */
const APP_NAME   = 'AgriSTIM';
const STORE_NAME = 'RJM Agrivet';
const APP_DEBUG  = true;                     // set to false when the system is used for real
const DB_HOST    = 'localhost';
const DB_NAME    = 'agristim';
const DB_USER    = 'root';
const DB_PASS    = '';
const SENSOR_KEY = 'CHANGE_ME_SENSOR_KEY';   // must match SENSOR_KEY in esp32/agristim_sensor.ino
const APP_TZ     = 'Asia/Manila';

ini_set('display_errors', APP_DEBUG ? '1' : '0');
error_reporting(E_ALL);
date_default_timezone_set(APP_TZ);

/* ---------- Sessions (skipped for the ESP32 sensor endpoint) ---------- */
if (!defined('NO_SESSION')) {
  $sessDir = __DIR__ . '/sessions';
  if (!is_dir($sessDir)) { mkdir($sessDir, 0777, true); }
  session_save_path($sessDir);
  session_name('AGRISTIM');
  if (PHP_VERSION_ID >= 70300) session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
  else session_set_cookie_params(0, '/', '', false, true);   // older PHP: same cookie, no SameSite option
  session_start();
}

/* ---------- Database ---------- */
try {
  $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
  // Keep MySQL and PHP on the same clock (fixes wrong "offline" / dates on XAMPP)
  $pdo->exec("SET time_zone='" . (new DateTime())->format('P') . "'");
} catch (PDOException $e) {
  if (defined('NO_SESSION')) { http_response_code(500); exit('{"error":"database unavailable"}'); }
  http_response_code(500);
  $detail = APP_DEBUG ? '<pre class="small text-muted mt-3 mb-0" style="white-space:pre-wrap">' . htmlspecialchars($e->getMessage()) . '</pre>' : '';
  exit('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Database not connected</title>'
    . '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="assets/style.css" rel="stylesheet"></head>'
    . '<body class="ag-auth"><div class="ag-auth-card card p-4" style="max-width:520px;margin:10vh auto"><h4 class="ag-display">Can&rsquo;t reach the database</h4>'
    . '<p class="text-muted mb-2">Open the XAMPP Control Panel and start <b>MySQL</b>. If this is a new install, import <b>database.sql</b> in phpMyAdmin, then open <b>setup.php</b>.</p>'
    . $detail . '</div></body></html>');
}

/* ---------- Small helpers ---------- */
function q($sql, $p = []) { global $pdo; $s = $pdo->prepare($sql); $s->execute($p); return $s; }
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function money($v) { return '&#8369;' . number_format((float)$v, 2); }
function temp($v) { return $v === null ? '--' : rtrim(rtrim(number_format((float)$v, 2, '.', ''), '0'), '.'); }
function nice_date($v, $time = true) { if (!$v) return '&mdash;'; $t = strtotime($v); return h(date($time ? 'M j, Y g:i A' : 'M j, Y', $t)); }
function me() { return $_SESSION['u'] ?? null; }
function is_owner() { return (me()['role'] ?? '') === 'owner'; }
function go($url) { header('Location: ' . $url); exit; }
function flash($type, $msg) { $_SESSION['flash'][] = [$type, $msg]; }
function post($k, $d = '') { return isset($_POST[$k]) ? (is_string($_POST[$k]) ? trim($_POST[$k]) : $_POST[$k]) : $d; }

/* ---------- CSRF protection for every form ---------- */
function csrf_token() { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16)); return $_SESSION['csrf']; }
function csrf_field() { return '<input type="hidden" name="_csrf" value="' . csrf_token() . '">'; }
if (!defined('NO_SESSION') && $_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!hash_equals(csrf_token(), (string)($_POST['_csrf'] ?? ''))) {
    flash('warning', 'The page was open too long. Please try again.');
    go($_SERVER['REQUEST_URI']);
  }
}

/* ---------- Login / roles ---------- */
function need($owner = false) {
  if (empty($_SESSION['u']['id'])) go('login.php');
  // Reload the account every request so deactivated users / role changes apply right away
  $u = q('SELECT id,username,full_name,role,active FROM users WHERE id=?', [$_SESSION['u']['id']])->fetch();
  if (!$u || !$u['active']) {
    $_SESSION = []; session_regenerate_id(true);
    flash('warning', 'Your account is no longer active. Please contact the owner.');
    go('login.php');
  }
  $_SESSION['u'] = $u;
  if ($owner && !is_owner()) {
    http_response_code(403);
    top('Owner only');
    echo '<div class="ag-card">' . empty_state('bi-shield-lock', 'Owner access only', 'This page is only available to the store owner.', '<a class="btn btn-success" href="index.php">Back to dashboard</a>') . '</div>';
    bottom(); exit;
  }
}

function audit($a) { q('INSERT INTO audit_log(user_id,action) VALUES(?,?)', [me()['id'] ?? null, mb_substr($a, 0, 255)]); }
function stock($pid) { return (int)q('SELECT COALESCE(SUM(qty_remaining),0) s FROM batches WHERE product_id=?', [$pid])->fetch()['s']; }

/* ---------- Alerts ---------- */
function alert_once($type, $ref, $msg) {
  if (!q("SELECT 1 FROM alerts WHERE type=? AND ref_id=? AND status<>'resolved'", [$type, $ref])->fetch())
    q('INSERT INTO alerts(type,ref_id,message) VALUES(?,?,?)', [$type, $ref, $msg]);
}
function auto_resolve($type, $ref, $remarks) {
  q("UPDATE alerts SET status='resolved',remarks=? WHERE type=? AND ref_id=? AND status<>'resolved'", [$remarks, $type, $ref]);
}
function run_checks() { // offline sensors, low stock, near/expired batches
  foreach (q("SELECT u.id,u.name FROM storage_units u LEFT JOIN temp_logs t ON t.unit_id=u.id GROUP BY u.id,u.name
              HAVING MAX(t.logged_at) IS NULL OR MAX(t.logged_at) < NOW() - INTERVAL 10 MINUTE") as $u)
    alert_once('offline', $u['id'], "No data from {$u['name']} for 10+ minutes");

  foreach (q('SELECT p.id,p.name,p.reorder_level,(SELECT COALESCE(SUM(qty_remaining),0) FROM batches WHERE product_id=p.id) s FROM products p WHERE p.archived=0') as $p) {
    if ((int)$p['s'] <= (int)$p['reorder_level']) alert_once('low_stock', $p['id'], "Low stock: {$p['name']}");
    else auto_resolve('low_stock', $p['id'], 'Stock replenished');
  }
  q("UPDATE alerts a JOIN products p ON p.id=a.ref_id SET a.status='resolved',a.remarks='Product archived'
     WHERE a.type='low_stock' AND a.status<>'resolved' AND p.archived=1");

  foreach (q('SELECT b.id,b.batch_no,p.name,b.expiry FROM batches b JOIN products p ON p.id=b.product_id
              WHERE b.qty_remaining>0 AND b.expiry IS NOT NULL AND b.expiry <= CURDATE() + INTERVAL 30 DAY') as $b) {
    $when = date('M j, Y', strtotime($b['expiry']));
    alert_once('expiry', $b['id'], $b['expiry'] < date('Y-m-d') ? "{$b['name']} (batch {$b['batch_no']}) expired on $when" : "{$b['name']} (batch {$b['batch_no']}) expires on $when");
  }
  q("UPDATE alerts a JOIN batches b ON b.id=a.ref_id SET a.status='resolved',a.remarks='Batch used up or removed'
     WHERE a.type='expiry' AND a.status<>'resolved' AND b.qty_remaining=0");
}
function alert_label($t) { return ['temp' => 'Temperature', 'offline' => 'Sensor offline', 'low_stock' => 'Low stock', 'expiry' => 'Expiry'][$t] ?? ucfirst($t); }
function alert_badge($t) {
  $cls = ['temp' => 'ag-badge-danger', 'offline' => 'ag-badge-dark', 'low_stock' => 'ag-badge-warn', 'expiry' => 'ag-badge-soil'][$t] ?? 'ag-badge-muted';
  $ico = ['temp' => 'bi-thermometer-high', 'offline' => 'bi-wifi-off', 'low_stock' => 'bi-box-seam', 'expiry' => 'bi-calendar-x'][$t] ?? 'bi-bell';
  return "<span class='ag-badge $cls'><i class='bi $ico'></i> " . h(alert_label($t)) . '</span>';
}
function status_badge($s) {
  $m = ['open' => ['ag-badge-danger', 'Open'], 'ack' => ['ag-badge-warn', 'Acknowledged'], 'resolved' => ['ag-badge-ok', 'Resolved']];
  $mm = $m[$s] ?? ['ag-badge-muted', ucfirst($s)]; $c = $mm[0]; $l = $mm[1];
  return "<span class='ag-badge $c'>$l</span>";
}

/* ---------- Categories (managed on categories.php) ---------- */
function ensure_categories() {
  if (!empty($_SESSION['cat_ok'])) return;
  q('CREATE TABLE IF NOT EXISTS categories(id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(60) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
  if (!q('SELECT COUNT(*) c FROM categories')->fetch()['c']) {
    foreach (['Feeds', 'Medicines', 'Antibiotics', 'Vitamins', 'Equipment', 'Supplies'] as $c) q('INSERT IGNORE INTO categories(name) VALUES(?)', [$c]);
    q("INSERT IGNORE INTO categories(name) SELECT DISTINCT category FROM products WHERE category<>''");
  }
  $_SESSION['cat_ok'] = 1;
}
function categories() { ensure_categories(); return array_column(q('SELECT name FROM categories ORDER BY name')->fetchAll(), 'name'); }

/* ---------- UI pieces ---------- */
function empty_state($icon, $title, $text = '', $action = '') {
  return "<div class='ag-empty'><div class='ag-empty-icon'><i class='bi $icon'></i></div><h6>" . h($title) . '</h6>'
    . ($text ? '<p>' . $text . '</p>' : '') . $action . '</div>';
}

function nav_items() {
  return [
    'Overview'   => [['index.php', 'Dashboard', 'bi-grid-1x2', false], ['alerts.php', 'Alerts', 'bi-bell', false]],
    'Inventory'  => [['products.php', is_owner() ? 'Products & Prices' : 'Inventory', 'bi-box-seam', false],
                     ['categories.php', 'Categories', 'bi-tags', true],
                     ['stock.php', 'Stock-In', 'bi-box-arrow-in-down', false],
                     ['stockout.php', 'Stock-Out / Losses', 'bi-box-arrow-up', false]],
    'Sales'      => [['sales.php', 'Sales / Bulk Orders', 'bi-cart3', false]],
    'Monitoring' => [['temperature.php', 'Temperature', 'bi-thermometer-half', false]],
    'Owner'      => [['reports.php', 'Reports', 'bi-bar-chart-line', true], ['users.php', 'Users', 'bi-people', true], ['audit.php', 'Audit Log', 'bi-journal-text', true]],
  ];
}

function head_tags($title) { ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= h($title) ?> | <?= APP_NAME ?></title>
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>&#127806;</text></svg>">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="assets/style.css?v=2" rel="stylesheet">
<?php }

function top($title, $subtitle = '', $actions = '') {
  $u = me(); $cur = basename($_SERVER['SCRIPT_NAME']);
  $open = $u ? (int)q("SELECT COUNT(*) c FROM alerts WHERE status<>'resolved'")->fetch()['c'] : 0;
  head_tags($title); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<script src="assets/app.js?v=2"></script>
</head><body class="ag-app">
<aside class="ag-sidebar offcanvas-lg offcanvas-start" tabindex="-1" id="sidebar">
  <div class="ag-brand">
    <span class="ag-logo">&#127806;</span>
    <div><div class="ag-brand-name"><?= APP_NAME ?></div><div class="ag-brand-sub"><?= STORE_NAME ?></div></div>
    <button type="button" class="btn-close btn-close-white ms-auto d-lg-none" data-bs-dismiss="offcanvas" data-bs-target="#sidebar" aria-label="Close"></button>
  </div>
  <nav class="ag-nav">
  <?php foreach (nav_items() as $group => $items):
      $items = array_filter($items, function ($i) { return !$i[3] || is_owner(); }); if (!$items) continue; ?>
    <div class="ag-nav-group"><?= h($group) ?></div>
    <?php foreach ($items as $it): list($file, $label, $icon) = $it; ?>
      <a class="ag-nav-link<?= $cur === $file ? ' active' : '' ?>" href="<?= $file ?>"><i class="bi <?= $icon ?>"></i><span><?= h($label) ?></span>
        <?php if ($file === 'alerts.php' && $open): ?><span class="ag-nav-count"><?= $open ?></span><?php endif; ?></a>
    <?php endforeach; ?>
  <?php endforeach; ?>
  </nav>
  <div class="ag-user">
    <div class="ag-avatar"><?= h(strtoupper(mb_substr($u['full_name'] ?? '?', 0, 1))) ?></div>
    <div class="ag-user-info"><div class="ag-user-name"><?= h($u['full_name'] ?? '') ?></div><div class="ag-user-role"><?= h(ucfirst($u['role'] ?? '')) ?></div></div>
    <a class="ag-logout" href="logout.php" title="Log out" aria-label="Log out"><i class="bi bi-box-arrow-right"></i></a>
  </div>
</aside>
<div class="ag-main">
  <header class="ag-topbar no-print">
    <button class="btn ag-icon-btn d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebar" aria-label="Open menu"><i class="bi bi-list"></i></button>
    <div class="ag-date d-none d-sm-flex"><i class="bi bi-calendar3"></i> <?= date('l, F j, Y') ?></div>
    <a href="alerts.php" class="btn ag-icon-btn ms-auto position-relative" aria-label="Alerts"><i class="bi bi-bell"></i>
      <?php if ($open): ?><span class="ag-dot"><?= $open > 99 ? '99+' : $open ?></span><?php endif; ?></a>
  </header>
  <main class="ag-content">
    <div class="ag-page-head">
      <div><h1 class="ag-title"><?= h($title) ?></h1><?php if ($subtitle): ?><p class="ag-subtitle"><?= $subtitle ?></p><?php endif; ?></div>
      <?php if ($actions): ?><div class="ag-page-actions no-print"><?= $actions ?></div><?php endif; ?>
    </div>
    <?php foreach ($_SESSION['flash'] ?? [] as $fl): $t = $fl[0]; $m = $fl[1]; ?>
      <div class="alert ag-alert alert-<?= h($t) ?> alert-dismissible fade show" role="alert"><?= $m ?><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>
    <?php endforeach; unset($_SESSION['flash']); ?>
<?php }

function bottom() { ?>
  </main>
  <footer class="ag-footer no-print"><?= APP_NAME ?> &middot; <?= STORE_NAME ?> Inventory &amp; Storage Monitoring</footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
<?php }
