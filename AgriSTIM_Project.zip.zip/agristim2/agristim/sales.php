<?php require 'config.php'; need();
$v = in_array($_GET['v'] ?? '', ['history', 'orders']) ? $_GET['v'] : 'new';
$SOLD = '(expiry IS NULL OR expiry >= CURDATE())';   // expired batches can never be sold

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $do = post('do');

  if ($do === 'sale') {
    $type = post('type') === 'bulk' ? 'bulk' : 'retail'; $cust = post('customer');
    $pids = (array)post('pid', []); $qtys = (array)post('qty', []); $want = [];
    foreach ($pids as $i => $pid) {            // merge duplicate product lines
      $pid = (int)$pid; $qt = $qtys[$i] ?? '';
      if (!$pid && $qt === '') continue;
      if (!$pid || !ctype_digit((string)$qt) || (int)$qt < 1) { flash('danger', 'Each line needs a product and a whole-number quantity.'); go('sales.php'); }
      $want[$pid] = ($want[$pid] ?? 0) + (int)$qt;
    }
    if (!$want) { flash('danger', 'Add at least one product.'); go('sales.php'); }
    if (mb_strlen($cust) > 100) { flash('danger', 'Customer name is too long.'); go('sales.php'); }
    try {
      $pdo->beginTransaction();
      $lines = []; $total = 0;
      ksort($want);                              // fixed lock order avoids deadlocks
      foreach ($want as $pid => $need) {
        $p = q('SELECT * FROM products WHERE id=? AND archived=0 FOR UPDATE', [$pid])->fetch();
        if (!$p) throw new RuntimeException('A product on the list is no longer available.');
        $bs = q("SELECT id,qty_remaining FROM batches WHERE product_id=? AND qty_remaining>0 AND $SOLD ORDER BY expiry IS NULL, expiry, id FOR UPDATE", [$pid])->fetchAll();
        $have = array_sum(array_column($bs, 'qty_remaining'));
        if ($have < $need) throw new RuntimeException("Not enough stock for {$p['name']}: only $have available (expired batches are not counted).");
        $left = $need;
        foreach ($bs as $b) {                    // first-to-expire batch first
          if ($left <= 0) break;
          $take = min($left, (int)$b['qty_remaining']);
          q('UPDATE batches SET qty_remaining=qty_remaining-? WHERE id=?', [$take, $b['id']]); $left -= $take;
        }
        $price = $type === 'bulk' && (float)$p['bulk_price'] > 0 ? (float)$p['bulk_price'] : (float)$p['retail_price'];
        $lines[] = [$pid, $need, $price, (float)$p['cost_price']]; $total += $need * $price;
      }
      q('INSERT INTO sales(type,customer,total,user_id) VALUES(?,?,?,?)', [$type, $cust ?: null, round($total, 2), me()['id']]);
      $sid = (int)$pdo->lastInsertId();
      foreach ($lines as $ln) { list($pid, $qt, $pr, $co) = $ln; q('INSERT INTO sale_items(sale_id,product_id,qty,unit_price,unit_cost) VALUES(?,?,?,?,?)', [$sid, $pid, $qt, $pr, $co]); }
      $pdo->commit();
    } catch (Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      flash('danger', $e instanceof RuntimeException ? h($e->getMessage()) : 'Could not save the sale. ' . (APP_DEBUG ? h($e->getMessage()) : ''));
      go('sales.php');
    }
    audit("sale #$sid $type total " . number_format($total, 2, '.', ''));
    run_checks();
    go("receipt.php?id=$sid");
  }

  if ($do === 'order') {
    $name = post('customer_name'); $tot = post('total_amount'); $pd = post('pickup_date'); $pt = post('pickup_time');
    if ($name === '' || mb_strlen($name) > 150) flash('danger', 'Please enter the customer name.');
    elseif ($tot === '' || !is_numeric($tot) || (float)$tot < 0) flash('danger', 'Total must be a number that is not negative.');
    elseif ($pd !== '' && !(($d = DateTime::createFromFormat('Y-m-d', $pd)) && $d->format('Y-m-d') === $pd)) flash('danger', 'Invalid pickup date.');
    else {
      $n = 1 + (int)q('SELECT COUNT(*) c FROM bulk_orders WHERE DATE(order_date)=CURDATE()')->fetch()['c'];
      $no = 'BO-' . date('Ymd') . '-' . str_pad($n, 3, '0', STR_PAD_LEFT);
      q('INSERT INTO bulk_orders(order_number,customer_name,contact_number,pickup_date,pickup_time,total_amount,notes) VALUES(?,?,?,?,?,?,?)',
        [$no, $name, post('contact_number') ?: null, $pd ?: null, $pt ?: null, round((float)$tot, 2), post('notes') ?: null]);
      audit("sale bulk order $no for $name"); flash('success', "Bulk order <b>$no</b> saved.");
    }
    go('sales.php?v=orders');
  }

  if ($do === 'order_status') {
    $os = ['Pending', 'Confirmed', 'Preparing', 'Ready for Pickup', 'Completed', 'Cancelled']; $ps = ['Unpaid', 'Partially Paid', 'Paid'];
    $o = q('SELECT * FROM bulk_orders WHERE order_id=?', [(int)post('id')])->fetch();
    if ($o && in_array(post('order_status'), $os, true) && in_array(post('payment_status'), $ps, true)) {
      q('UPDATE bulk_orders SET order_status=?,payment_status=? WHERE order_id=?', [post('order_status'), post('payment_status'), $o['order_id']]);
      audit("sale bulk order {$o['order_number']} " . post('order_status') . ' / ' . post('payment_status')); flash('success', 'Order updated.');
    }
    go('sales.php?v=orders');
  }
  go('sales.php');
}

$prods = q("SELECT p.id,p.name,p.unit,p.retail_price r,p.bulk_price b,
   COALESCE((SELECT SUM(qty_remaining) FROM batches WHERE product_id=p.id AND $SOLD),0) stock FROM products p WHERE p.archived=0 ORDER BY p.name")->fetchAll();
top('Sales / Bulk Orders', 'Record sales (oldest stock is used first) and keep track of bulk pickup orders.'); ?>
<div class="ag-pills mb-3"><a class="<?= $v === 'new' ? 'active' : '' ?>" href="sales.php">New sale</a><a class="<?= $v === 'history' ? 'active' : '' ?>" href="sales.php?v=history">Sales history</a><a class="<?= $v === 'orders' ? 'active' : '' ?>" href="sales.php?v=orders">Bulk orders</a></div>

<?php if ($v === 'new'): ?>
<div class="ag-card ag-card-form"><form method="post" id="saleForm"><?= csrf_field() ?><input type="hidden" name="do" value="sale">
  <div class="row g-3 mb-3">
    <div class="col-md-6"><label class="form-label">Sale type</label><div class="ag-segment">
      <input type="radio" name="type" id="t1" value="retail" checked><label for="t1">Retail</label><input type="radio" name="type" id="t2" value="bulk"><label for="t2">Bulk price</label></div></div>
    <div class="col-md-6"><label class="form-label">Customer (optional)</label><input class="form-control" name="customer" maxlength="100" placeholder="Walk-in"></div>
  </div>
  <div class="table-responsive"><table class="table"><thead><tr><th>Product</th><th style="width:130px">Qty</th><th class="ag-num">Price</th><th class="ag-num">Amount</th><th></th></tr></thead><tbody id="items"></tbody></table></div>
  <button type="button" class="btn btn-light mt-2" id="addRow"><i class="bi bi-plus-lg me-1"></i>Add product</button>
  <div class="ag-total"><div><div class="ag-total-label">Total</div></div><div class="ag-total-value" id="total">&#8369;0.00</div></div>
  <button class="btn btn-success mt-3 px-4"><i class="bi bi-check2 me-1"></i>Complete sale</button>
</form></div>
<script>
document.addEventListener('DOMContentLoaded', function () {
  var P = <?= json_encode($prods, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  var body = document.getElementById('items'), form = document.getElementById('saleForm');
  function peso(n) { return '₱' + n.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}); }
  function bulk() { return form.type.value === 'bulk'; }
  function price(p) { return bulk() && parseFloat(p.b) > 0 ? parseFloat(p.b) : parseFloat(p.r); }
  function addRow() {
    var tr = document.createElement('tr'), sel = document.createElement('select');
    sel.name = 'pid[]'; sel.className = 'form-select form-select-sm';
    sel.innerHTML = '<option value="">Choose product&hellip;</option>';
    P.forEach(function (p) { var o = document.createElement('option'); o.value = p.id; o.disabled = +p.stock < 1; o.textContent = p.name + ' (' + p.stock + ' ' + p.unit + ' available)'; sel.appendChild(o); });
    tr.innerHTML = '<td></td><td><input class="form-control form-control-sm" type="number" name="qty[]" min="1" step="1" value="1"></td><td class="ag-num pr">&mdash;</td><td class="ag-num am">&mdash;</td><td class="text-end"><button type="button" class="btn btn-sm btn-outline-danger" title="Remove"><i class="bi bi-x-lg"></i></button></td>';
    tr.firstChild.appendChild(sel); body.appendChild(tr);
    sel.addEventListener('change', calc); tr.querySelector('input').addEventListener('input', calc);
    tr.querySelector('button').addEventListener('click', function () { if (body.children.length > 1) { tr.remove(); calc(); } });
  }
  function calc() {
    var t = 0;
    Array.prototype.forEach.call(body.children, function (tr) {
      var p = P.filter(function (x) { return x.id == tr.querySelector('select').value; })[0], q = parseInt(tr.querySelector('input').value, 10) || 0;
      var input = tr.querySelector('input');
      if (p) { input.max = p.stock; var pr = price(p); tr.querySelector('.pr').textContent = peso(pr); tr.querySelector('.am').textContent = peso(pr * q); t += pr * q; }
      else { tr.querySelector('.pr').innerHTML = '&mdash;'; tr.querySelector('.am').innerHTML = '&mdash;'; }
    });
    document.getElementById('total').textContent = peso(t);
  }
  document.getElementById('addRow').addEventListener('click', addRow);
  Array.prototype.forEach.call(form.type, function (r) { r.addEventListener('change', calc); });
  addRow();
});
</script>

<?php elseif ($v === 'history'):
  $rows = q('SELECT s.*,u.full_name,(SELECT COUNT(*) FROM sale_items WHERE sale_id=s.id) n FROM sales s LEFT JOIN users u ON u.id=s.user_id ORDER BY s.id DESC LIMIT 60')->fetchAll(); ?>
<div class="ag-card"><?php if (!$rows): echo empty_state('bi-cart3', 'No sales yet', 'Completed sales will appear here.', '<a class="btn btn-success" href="sales.php">New sale</a>'); else: ?>
  <div class="table-responsive"><table class="table"><thead><tr><th>Receipt</th><th>Date</th><th>Customer</th><th>Type</th><th class="ag-num">Items</th><th class="ag-num">Total</th><th>Cashier</th><th></th></tr></thead><tbody>
  <?php foreach ($rows as $s): ?><tr><td class="ag-strong">#<?= (int)$s['id'] ?></td><td class="text-nowrap small"><?= nice_date($s['created_at']) ?></td><td><?= h($s['customer'] ?: 'Walk-in') ?></td>
    <td><span class="ag-badge <?= $s['type'] === 'bulk' ? 'ag-badge-soil' : 'ag-badge-ok' ?>"><?= h(ucfirst($s['type'])) ?></span></td><td class="ag-num"><?= (int)$s['n'] ?></td><td class="ag-num ag-strong"><?= money($s['total']) ?></td><td><?= h($s['full_name'] ?: '—') ?></td>
    <td class="text-end"><a class="btn btn-sm btn-light" href="receipt.php?id=<?= (int)$s['id'] ?>"><i class="bi bi-receipt"></i> Receipt</a></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></div>

<?php else:
  $orders = q('SELECT * FROM bulk_orders ORDER BY order_id DESC LIMIT 60')->fetchAll();
  $os = ['Pending', 'Confirmed', 'Preparing', 'Ready for Pickup', 'Completed', 'Cancelled']; $ps = ['Unpaid', 'Partially Paid', 'Paid']; ?>
<div class="row g-4">
  <div class="col-lg-4"><div class="ag-card ag-card-form"><div class="ag-card-head"><h2 class="ag-card-title"><i class="bi bi-plus-circle"></i> New bulk order</h2></div>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="order">
      <label class="form-label">Customer</label><input class="form-control mb-2" name="customer_name" maxlength="150" required>
      <label class="form-label">Contact number</label><input class="form-control mb-2" name="contact_number" maxlength="30">
      <div class="row g-2 mb-2"><div class="col-7"><label class="form-label">Pickup date</label><input class="form-control" type="date" name="pickup_date"></div><div class="col-5"><label class="form-label">Time</label><input class="form-control" type="time" name="pickup_time"></div></div>
      <label class="form-label">Order total (&#8369;)</label><input class="form-control mb-2" type="number" name="total_amount" min="0" step="0.01" required>
      <label class="form-label">Items / notes</label><textarea class="form-control mb-3" name="notes" rows="3" placeholder="e.g. 20 sacks Hog Feeds"></textarea>
      <button class="btn btn-success w-100">Save order</button>
      <p class="text-muted small mt-2 mb-0">Stock is only deducted when you record the actual sale under <b>New sale</b> (choose &ldquo;Bulk price&rdquo;).</p>
    </form></div></div>
  <div class="col-lg-8"><div class="ag-card"><?php if (!$orders): echo empty_state('bi-bag', 'No bulk orders', 'Orders you save will appear here.'); else: ?>
    <div class="table-responsive"><table class="table"><thead><tr><th>Order</th><th>Customer</th><th>Pickup</th><th class="ag-num">Total</th><th style="min-width:330px">Status</th></tr></thead><tbody>
    <?php foreach ($orders as $o): ?><tr><td class="ag-strong"><?= h($o['order_number']) ?><span class="ag-sub"><?= nice_date($o['order_date'], false) ?></span></td>
      <td><?= h($o['customer_name']) ?><span class="ag-sub"><?= h($o['contact_number']) ?><?= $o['notes'] ? ' &middot; ' . h($o['notes']) : '' ?></span></td>
      <td class="text-nowrap small"><?= nice_date($o['pickup_date'], false) ?><?= $o['pickup_time'] ? '<span class="ag-sub">' . h(date('g:i A', strtotime($o['pickup_time']))) . '</span>' : '' ?></td><td class="ag-num"><?= money($o['total_amount']) ?></td>
      <td><form method="post" class="d-flex gap-1"><?= csrf_field() ?><input type="hidden" name="do" value="order_status"><input type="hidden" name="id" value="<?= (int)$o['order_id'] ?>">
        <select class="form-select form-select-sm" name="order_status"><?php foreach ($os as $x): ?><option <?= $x === $o['order_status'] ? 'selected' : '' ?>><?= h($x) ?></option><?php endforeach; ?></select>
        <select class="form-select form-select-sm" name="payment_status"><?php foreach ($ps as $x): ?><option <?= $x === $o['payment_status'] ? 'selected' : '' ?>><?= h($x) ?></option><?php endforeach; ?></select>
        <button class="btn btn-sm btn-light"><i class="bi bi-check2"></i></button></form></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></div></div>
</div>
<?php endif; ?>
<?php bottom();
