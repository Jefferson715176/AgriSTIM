<?php require 'config.php'; need();
$s = q('SELECT s.*,u.full_name FROM sales s LEFT JOIN users u ON u.id=s.user_id WHERE s.id=?', [(int)($_GET['id'] ?? 0)])->fetch();
if (!$s) { flash('danger', 'Receipt not found.'); go('sales.php?v=history'); }
$items = q('SELECT si.*,p.name,p.unit FROM sale_items si LEFT JOIN products p ON p.id=si.product_id WHERE si.sale_id=? ORDER BY si.id', [$s['id']])->fetchAll();
top('Receipt #' . (int)$s['id'], '', '<button class="btn btn-success" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print</button> <a class="btn btn-light" href="sales.php">New sale</a>'); ?>
<div class="ag-receipt">
  <div class="text-center"><h2><?= h(STORE_NAME) ?></h2><div class="text-muted small">Official receipt</div></div>
  <div class="ag-dash"></div>
  <table><tr><td>Receipt no.</td><td class="text-end">#<?= (int)$s['id'] ?></td></tr>
    <tr><td>Date</td><td class="text-end"><?= nice_date($s['created_at']) ?></td></tr>
    <tr><td>Customer</td><td class="text-end"><?= h($s['customer'] ?: 'Walk-in') ?></td></tr>
    <tr><td>Type</td><td class="text-end"><?= h(ucfirst($s['type'])) ?></td></tr>
    <tr><td>Cashier</td><td class="text-end"><?= h($s['full_name'] ?: '—') ?></td></tr></table>
  <div class="ag-dash"></div>
  <table><?php foreach ($items as $i): ?>
    <tr><td><?= h($i['name'] ?: 'Item') ?><div class="text-muted small"><?= (int)$i['qty'] ?> &times; <?= money($i['unit_price']) ?></div></td><td class="text-end"><?= money($i['qty'] * $i['unit_price']) ?></td></tr><?php endforeach; ?></table>
  <div class="ag-dash"></div>
  <table><tr><td class="ag-strong">TOTAL</td><td class="text-end ag-display" style="font-size:1.4rem"><?= money($s['total']) ?></td></tr></table>
  <div class="ag-dash"></div>
  <p class="text-center text-muted small mb-0">Thank you for shopping at <?= h(STORE_NAME) ?>!</p>
</div>
<?php bottom();
