<?php require 'config.php';
if (!empty($_SESSION['u']['id'])) go('index.php');
$err = '';
$wait = max(0, ($_SESSION['lock_until'] ?? 0) - time());
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if ($wait > 0) {
    $err = "Too many attempts. Please wait $wait seconds.";
  } else {
    $u = q('SELECT * FROM users WHERE username=? AND active=1', [strtolower(post('username'))])->fetch();
    if ($u && password_verify((string)post('password'), $u['password_hash'])) {
      session_regenerate_id(true);
      unset($u['password_hash']);                        // never keep the password hash in the session
      $_SESSION['u'] = $u; $_SESSION['fails'] = 0;
      audit('login');
      go('index.php');
    }
    $_SESSION['fails'] = ($_SESSION['fails'] ?? 0) + 1;
    if ($_SESSION['fails'] >= 5) { $_SESSION['lock_until'] = time() + 60; $_SESSION['fails'] = 0; $err = 'Too many attempts. Please wait 60 seconds.'; }
    else $err = 'Invalid username or password.';
  }
}
head_tags('Log in'); ?>
</head><body class="ag-auth">
<div class="ag-auth-wrap">
  <section class="ag-auth-art d-flex">
    <div class="d-flex align-items-center gap-2 position-relative" style="z-index:1"><span class="ag-logo">&#127806;</span>
      <div><div class="ag-brand-name"><?= APP_NAME ?></div><div class="ag-brand-sub"><?= STORE_NAME ?></div></div></div>
    <div class="position-relative" style="z-index:1">
      <h2>Inventory &amp; cold storage, in one calm place.</h2>
      <p class="mt-3">Track feeds, medicines and vaccines, watch storage temperatures live, and catch low stock and expiring batches early.</p>
    </div>
    <div class="ag-auth-feats">
      <div class="ag-auth-feat"><i class="bi bi-thermometer-snow"></i> Live temperature monitoring from ESP32 sensors</div>
      <div class="ag-auth-feat"><i class="bi bi-calendar2-check"></i> Batch &amp; expiry tracking, first-to-expire selling</div>
      <div class="ag-auth-feat"><i class="bi bi-graph-up-arrow"></i> Sales, losses and profit reports</div>
    </div>
  </section>
  <section class="ag-auth-form">
    <div class="ag-auth-card">
      <div class="d-lg-none text-center mb-3"><span class="ag-logo mx-auto">&#127806;</span></div>
      <h1 class="ag-display mb-1" style="font-size:2rem;color:var(--ag-forest)">Welcome back</h1>
      <p class="text-muted mb-4">Log in to <?= STORE_NAME ?> Inventory &amp; Storage Monitoring.</p>
      <?php foreach ($_SESSION['flash'] ?? [] as $fl): $t = $fl[0]; $m = $fl[1]; ?><div class="alert ag-alert alert-<?= h($t) ?> py-2"><?= $m ?></div><?php endforeach; unset($_SESSION['flash']); ?>
      <?php if ($err): ?><div class="alert ag-alert alert-danger py-2"><i class="bi bi-exclamation-circle me-1"></i><?= h($err) ?></div><?php endif; ?>
      <form method="post" autocomplete="on"><?= csrf_field() ?>
        <label class="form-label" for="username">Username</label>
        <div class="input-group mb-3"><span class="input-group-text"><i class="bi bi-person"></i></span>
          <input class="form-control" id="username" name="username" value="<?= h(post('username')) ?>" autocomplete="username" required autofocus></div>
        <label class="form-label" for="pw">Password</label>
        <div class="input-group mb-4"><span class="input-group-text"><i class="bi bi-lock"></i></span>
          <input class="form-control" type="password" name="password" id="pw" autocomplete="current-password" required>
          <button class="btn btn-light" type="button" id="eye" aria-label="Show password" title="Show / hide password"><i class="bi bi-eye"></i></button></div>
        <button class="btn btn-success w-100 py-2">Log in <i class="bi bi-arrow-right ms-1"></i></button>
      </form>
      <p class="text-muted small text-center mt-4 mb-0">Forgot your password? Ask the store owner to reset it.</p>
    </div>
  </section>
</div>
<script>
document.getElementById('eye').addEventListener('click', function () {
  const pw = document.getElementById('pw'), show = pw.type === 'password';
  pw.type = show ? 'text' : 'password';
  this.innerHTML = show ? '<i class="bi bi-eye-slash"></i>' : '<i class="bi bi-eye"></i>';
  this.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
});
</script></body></html>
